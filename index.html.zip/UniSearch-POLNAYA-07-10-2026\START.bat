@echo off
cd /d "%~dp0"
chcp 65001 >nul
title UniSearch
echo.
echo UniSearch starting...
echo Do not close this window while the site is open.
echo Admin: http://127.0.0.1:4173/admin/login
echo cabinet@unisearch.local / UniSearch-Cabinet-4821
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo START failed with code %ERR%.
  echo If Python is missing: install Python 3.12 and tick "Add to PATH".
  pause
  exit /b %ERR%
)
echo UniSearch stopped.
pause
