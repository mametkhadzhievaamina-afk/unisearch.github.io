# UniSearch API (Django)

Stage 1 skeleton: Django + DRF + CORS + health + Postgres-ready settings.

## Production (one VPS)

Bots get HTML for `/university/:id` from `GET /seo/university/{id}/`. Humans use the SPA; nginx (`deploy/nginx.conf`) sends bot user-agents to that endpoint. `sitemap.xml` and `robots.txt` are served by Django. Frontend also sets title, description, canonical, Open Graph and JSON-LD in the browser.

```
sh deploy.sh
```

Set `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0`, hosts, CORS, `SITE_URL`, SMTP and SMS in `backend/.env`. Create the admin with `createsuperuser` (password is not stored in the repo). Django admin path is `DJANGO_ADMIN_PATH` (example: `staff`) so it does not collide with the SPA `/admin` cabinet.

New env: `DJANGO_ADMIN_PATH`, `SITE_URL`, `NUM_PROXIES`, `DJANGO_CACHE`, `DJANGO_SECURE_SSL_REDIRECT`, `EMAIL_*`, `SMS_PROVIDER`, `ESKIZ_*`, `TURNSTILE_SECRET`, `DJANGO_SUPERUSER_*` (optional, only in the server environment).

Auth additions (old register/login stay): `POST /api/v1/auth/verify/request/`, `.../confirm/`, `.../password-reset/request/`, `.../confirm/`.

HTTPS: put Caddy or Certbot in front of port 80, `reverse_proxy localhost:80`.


## Quick start (this machine)

Postgres/Docker are not installed yet, so local smoke tests use SQLite:

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python manage.py migrate
python manage.py runserver 127.0.0.1:8000
```

Health: [http://127.0.0.1:8000/api/v1/health/](http://127.0.0.1:8000/api/v1/health/)

## Postgres (preferred)

1. Install Docker Desktop **or** local PostgreSQL.
2. `docker compose up -d`
3. In `.env` set `DJANGO_USE_SQLITE=0` and matching `POSTGRES_*` values.
4. `python manage.py migrate`

## Catalog API (Stage 2)

```
GET /api/v1/universities/?q=&city=&cost=&ielts=&grant=&field=&sort=&page=
GET /api/v1/universities/{id}/          # + embedded programs[]
GET /api/v1/programs/?uniId= | ?uni_id= | ?q=
GET /api/v1/scholarships/
```

Pagination (universities only): DRF `{ count, next, previous, results }` — `PAGE_SIZE=20`.
Programs/scholarships: full array (no pagination).

Seed from fixtures (exported from frontend data):

```powershell
python manage.py seed_catalog --clear
```

Response keys are camelCase (`nameRu`, `ieltsBonus`, …) to match `src/types.ts`.
Internal filter helpers (`costUsd`, `needsIelts`, `grantFriendly`) stay server-side and are not exposed.

## Auth API (Stage 3)

```
POST /api/v1/auth/register/   { name?, email?, phone?, password }  # min password 8; email or phone required
POST /api/v1/auth/login/      { login, password }                  # login = email or phone
POST /api/v1/auth/refresh/    { refresh }
POST /api/v1/auth/logout/     { refresh }                          # Bearer required
GET  /api/v1/auth/me/
PATCH /api/v1/auth/me/        { name }
POST /api/v1/me/merge-local/  { savedIds[], dtmHistory[] }         # after login
GET|PUT /api/v1/me/saved/     { savedIds }
```

JWT access/refresh tokens. FE stores tokens in `localStorage` key `unisearch-auth-tokens` (separate from Zustand `unisearch-app`).

## Comments & checklist

```
GET  /api/v1/comments/
POST /api/v1/comments/              { name, text }  # throttled
GET  /api/v1/checklist/template/
GET|PUT /api/v1/me/checklist/       { checklist: { id: bool } }
```

FE loads catalog from API (`useCatalogStore`) with static fallback if API is down.
