from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ('id', 'username', 'name', 'email', 'phone', 'is_staff', 'is_active')
    search_fields = ('username', 'name', 'email', 'phone')
    fieldsets = DjangoUserAdmin.fieldsets + (
        ('UniSearch', {'fields': ('name', 'phone')}),
    )
    add_fieldsets = DjangoUserAdmin.add_fieldsets + (
        ('UniSearch', {'fields': ('name', 'email', 'phone')}),
    )
