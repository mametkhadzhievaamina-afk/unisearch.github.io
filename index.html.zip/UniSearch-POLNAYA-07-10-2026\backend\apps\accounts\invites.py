import hashlib
import secrets
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from .models import AdminInvite

INVITE_HOURS = 48


def hash_invite(raw: str) -> str:
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def create_invite(created_by=None) -> tuple[str, AdminInvite]:
    raw = secrets.token_urlsafe(32)
    invite = AdminInvite.objects.create(
        token_hash=hash_invite(raw),
        created_by=created_by if getattr(created_by, 'is_authenticated', True) else None,
        expires_at=timezone.now() + timedelta(hours=INVITE_HOURS),
    )
    return raw, invite


def lock_invite(raw: str) -> AdminInvite | None:
    token = (raw or '').strip()
    if len(token) < 20:
        return None
    return (
        AdminInvite.objects.select_for_update()
        .filter(token_hash=hash_invite(token), used_at__isnull=True, expires_at__gt=timezone.now())
        .first()
    )


@transaction.atomic
def consume_invite(raw: str, user) -> bool:
    invite = lock_invite(raw)
    if invite is None:
        return False
    invite.used_at = timezone.now()
    invite.used_by = user
    invite.save(update_fields=['used_at', 'used_by'])
    return True
