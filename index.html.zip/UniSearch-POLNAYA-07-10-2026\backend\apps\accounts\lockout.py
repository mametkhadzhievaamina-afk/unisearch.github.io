import hashlib
import logging

from django.conf import settings
from django.core.cache import cache

logger = logging.getLogger('apps.accounts.sms')

LOCK_AFTER = 5
LOCK_SECONDS = 15 * 60


def client_ip(request) -> str:
    """Client address behind one trusted proxy (NUM_PROXIES)."""
    remote = request.META.get('REMOTE_ADDR') or ''
    xff = request.META.get('HTTP_X_FORWARDED_FOR') or ''
    if not xff:
        return remote
    parts = [part.strip() for part in xff.split(',') if part.strip()]
    hops = max(1, int(getattr(settings, 'NUM_PROXIES', 1) or 1))
    if len(parts) >= hops:
        return parts[-hops]
    return parts[0] if parts else remote


def _key(ip: str, login: str) -> str:
    raw = f'{ip}|{login.strip().lower()}'.encode()
    return 'login-fail:' + hashlib.sha256(raw).hexdigest()


def is_locked(request, login: str) -> bool:
    return bool(cache.get(_key(client_ip(request), login)))


def register_failure(request, login: str) -> None:
    key = _key(client_ip(request), login)
    count_key = key + ':n'
    count = cache.get(count_key, 0) + 1
    cache.set(count_key, count, LOCK_SECONDS)
    if count >= LOCK_AFTER:
        cache.set(key, 1, LOCK_SECONDS)


def clear_failures(request, login: str) -> None:
    key = _key(client_ip(request), login)
    cache.delete(key)
    cache.delete(key + ':n')
