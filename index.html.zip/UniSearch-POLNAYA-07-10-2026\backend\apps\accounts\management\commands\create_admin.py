from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = 'Create or promote the first administrator from the server. Not available over HTTP.'

    def add_arguments(self, parser):
        parser.add_argument('--email', required=True)
        parser.add_argument('--password', required=True)
        parser.add_argument('--name', default='Admin')

    def handle(self, *args, **options):
        email = options['email'].strip().lower()
        password = options['password']
        if len(password) < 8 or '@' not in email:
            raise CommandError('Need a valid email and a password of at least 8 characters.')
        User = get_user_model()
        user = User.objects.filter(email__iexact=email).first()
        if user is None:
            user = User(username=email, email=email, name=options['name'])
            user.set_password(password)
        else:
            user.email = email
            user.name = user.name or options['name']
            user.set_password(password)
        user.is_staff = True
        user.is_superuser = True
        user.is_active = True
        user.save()
        self.stdout.write(self.style.SUCCESS(f'Staff account ready: {email}'))
