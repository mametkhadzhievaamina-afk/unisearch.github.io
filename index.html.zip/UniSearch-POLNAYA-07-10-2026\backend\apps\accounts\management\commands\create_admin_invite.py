from django.core.management.base import BaseCommand

from apps.accounts.invites import INVITE_HOURS, create_invite


class Command(BaseCommand):
    help = 'Print a one-time admin invitation. The token is stored only as a hash.'

    def handle(self, *args, **options):
        raw, invite = create_invite(None)
        self.stdout.write(f'/admin/register?invite={raw}')
        self.stdout.write(f'Expires in {INVITE_HOURS} hours. id={invite.id}')
