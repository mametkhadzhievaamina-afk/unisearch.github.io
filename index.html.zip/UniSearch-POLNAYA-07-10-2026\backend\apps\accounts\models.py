from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Matches frontend CurrentUser / UserAccount identity:
    - name, email | phone (at least one identifier)
    - password hashed (never returned by API)
    """

    name = models.CharField(max_length=120, blank=True, default='')
    email = models.EmailField(blank=True, null=True, unique=True)
    phone = models.CharField(max_length=32, blank=True, null=True, unique=True)
    is_phone_verified = models.BooleanField(default=False)
    is_email_verified = models.BooleanField(default=False)

    REQUIRED_FIELDS = ['name']

    def __str__(self) -> str:
        return self.name or self.email or self.phone or self.username


class AdminInvite(models.Model):
    """One-time staff invitation. Only the token hash is stored."""

    token_hash = models.CharField(max_length=64, unique=True)
    created_by = models.ForeignKey(
        'User',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='admin_invites_created',
    )
    used_by = models.ForeignKey(
        'User',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='admin_invite_used',
    )
    expires_at = models.DateTimeField()
    used_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class VerificationCode(models.Model):
    """One-time code. Only the hash is stored."""

    PURPOSE_PHONE = 'phone'
    PURPOSE_EMAIL = 'email'
    PURPOSE_RESET = 'reset'
    PURPOSES = (
        (PURPOSE_PHONE, 'phone'),
        (PURPOSE_EMAIL, 'email'),
        (PURPOSE_RESET, 'reset'),
    )

    purpose = models.CharField(max_length=16, choices=PURPOSES)
    target = models.CharField(max_length=255)
    code_hash = models.CharField(max_length=64)
    attempts = models.PositiveSmallIntegerField(default=0)
    expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['purpose', 'target', 'created_at']),
        ]
