import re

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Q
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

User = get_user_model()

EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
PHONE_RE = re.compile(r'^\+?[\d\s\-()]{7,32}$')
UZ_NATIONAL = re.compile(r'[1-9]\d{8}$')


def to_e164_uz(raw: str) -> str | None:
    digits = re.sub(r'\D', '', raw or '')
    if digits.startswith('998') and len(digits) == 12:
        national = digits[3:]
    elif len(digits) == 9:
        national = digits
    else:
        return None
    if not UZ_NATIONAL.match(national):
        return None
    return '+998' + national


def normalize_phone(raw: str) -> str:
    return re.sub(r'[\s\-()]', '', raw.strip())


def looks_like_email(value: str) -> bool:
    return bool(EMAIL_RE.match(value.strip()))


class UserSerializer(serializers.ModelSerializer):
    """Frontend CurrentUser shape."""

    email = serializers.SerializerMethodField()
    phone = serializers.SerializerMethodField()
    isStaff = serializers.BooleanField(source='is_staff', read_only=True)

    class Meta:
        model = User
        fields = ['name', 'email', 'phone', 'isStaff']
        read_only_fields = ['email', 'phone', 'isStaff']
        extra_kwargs = {
            'name': {'required': False},
        }

    def get_email(self, obj: User):
        return obj.email or None

    def get_phone(self, obj: User):
        return obj.phone or None

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.save(update_fields=['name'])
        return instance


class RegisterSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120, required=False, allow_blank=True, default='')
    email = serializers.EmailField(required=False, allow_null=True, allow_blank=True)
    phone = serializers.CharField(max_length=32, required=False, allow_null=True, allow_blank=True)
    password = serializers.CharField(write_only=True, min_length=8, max_length=128)

    def validate(self, attrs):
        email = (attrs.get('email') or '').strip().lower() or None
        phone_raw = (attrs.get('phone') or '').strip()
        if phone_raw:
            e164 = to_e164_uz(phone_raw)
            if not e164:
                raise serializers.ValidationError({'phone': 'Enter a Uzbekistan number, +998XXXXXXXXX.'})
            phone = e164
        else:
            phone = None

        if not email and not phone:
            raise serializers.ValidationError({'login': 'Email or phone is required.'})

        if phone and not PHONE_RE.match(phone_raw):
            raise serializers.ValidationError({'phone': 'Invalid phone number.'})

        if email and User.objects.filter(email__iexact=email).exists():
            raise serializers.ValidationError({'email': 'Account already exists.'})
        if phone and User.objects.filter(phone=phone).exists():
            raise serializers.ValidationError({'phone': 'Account already exists.'})

        try:
            validate_password(attrs['password'])
        except DjangoValidationError as exc:
            raise serializers.ValidationError({'password': list(exc.messages)}) from exc

        attrs['email'] = email
        attrs['phone'] = phone
        attrs['name'] = (attrs.get('name') or '').strip()
        return attrs

    def create(self, validated_data):
        email = validated_data.get('email')
        phone = validated_data.get('phone')
        name = validated_data.get('name') or (email.split('@')[0] if email else (phone or 'User'))
        username = email or phone
        # Ensure unique username
        base = username
        n = 0
        while User.objects.filter(username=username).exists():
            n += 1
            username = f'{base}_{n}'

        user = User(username=username, email=email, phone=phone, name=name)
        user.set_password(validated_data['password'])
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    """Accept `login` (email or phone) or legacy email/phone fields + password."""

    login = serializers.CharField(required=False, allow_blank=True)
    email = serializers.CharField(required=False, allow_blank=True)
    phone = serializers.CharField(required=False, allow_blank=True)
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        login = (attrs.get('login') or attrs.get('email') or attrs.get('phone') or '').strip()
        password = attrs.get('password') or ''
        if not login or not password:
            raise serializers.ValidationError({'login': 'Login and password are required.'})
        if len(password) < 8:
            raise serializers.ValidationError({'password': 'Password must be at least 8 characters.'})

        user = None
        if looks_like_email(login):
            user = User.objects.filter(email__iexact=login.lower()).first()
            if user is None and login.lower() == 'admin@unisearch.local':
                user = User.objects.filter(username='admin').first()
        else:
            phone = to_e164_uz(login) or normalize_phone(login)
            user = User.objects.filter(
                Q(phone=phone) | Q(phone=normalize_phone(login)) | Q(username__iexact=login)
            ).first()

        if user is None or not user.check_password(password) or not user.is_active:
            raise serializers.ValidationError({'detail': 'Wrong login or password.'})

        attrs['user'] = user
        return attrs


def tokens_for(user: User) -> dict:
    refresh = RefreshToken.for_user(user)
    return {
        'access': str(refresh.access_token),
        'refresh': str(refresh),
        'user': UserSerializer(user).data,
    }
