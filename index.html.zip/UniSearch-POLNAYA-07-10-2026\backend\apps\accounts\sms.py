import logging
from urllib import parse, request as urlrequest

from django.conf import settings

logger = logging.getLogger('apps.accounts.sms')


class SmsProvider:
    """Replace this with a real gateway. Telegram is intentionally not implemented."""

    def send(self, phone_e164: str, text: str) -> None:
        raise NotImplementedError


class LogSmsProvider(SmsProvider):
    def send(self, phone_e164: str, text: str) -> None:
        logger.info('SMS to %s: %s', phone_e164, text)


class EskizSmsProvider(SmsProvider):
    """Eskiz.uz notify. Needs ESKIZ_EMAIL, ESKIZ_PASSWORD, ESKIZ_FROM."""

    def send(self, phone_e164: str, text: str) -> None:
        email = settings.ESKIZ_EMAIL
        password = settings.ESKIZ_PASSWORD
        if not email or not password:
            raise RuntimeError('Eskiz credentials are not configured.')
        login_body = parse.urlencode({'email': email, 'password': password}).encode()
        with urlrequest.urlopen(
            urlrequest.Request('https://notify.eskiz.uz/api/auth/login', data=login_body, method='POST'),
            timeout=15,
        ) as resp:
            import json
            token = json.loads(resp.read().decode()).get('data', {}).get('token')
        if not token:
            raise RuntimeError('Eskiz login failed.')
        send_body = parse.urlencode({
            'mobile_phone': phone_e164.lstrip('+'),
            'message': text,
            'from': settings.ESKIZ_FROM or '4546',
        }).encode()
        req = urlrequest.Request(
            'https://notify.eskiz.uz/api/message/sms/send',
            data=send_body,
            method='POST',
            headers={'Authorization': f'Bearer {token}'},
        )
        with urlrequest.urlopen(req, timeout=15):
            return


def get_sms_provider() -> SmsProvider:
    if (getattr(settings, 'SMS_PROVIDER', 'log') or 'log').lower() == 'eskiz':
        return EskizSmsProvider()
    return LogSmsProvider()
