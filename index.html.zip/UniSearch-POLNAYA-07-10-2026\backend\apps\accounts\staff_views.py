from django.contrib.auth import get_user_model
from django.db.models import Count
from rest_framework import serializers, status
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.invites import INVITE_HOURS, create_invite
from apps.catalog.models import Program, Scholarship, University
from apps.community.models import Comment

User = get_user_model()


def _money(amount: int) -> tuple[str, str, str]:
    pretty = f'{int(amount):,}'
    if not amount:
        return '', '', ''
    return f'от ${pretty}', f'{pretty} $ dan', f'from ${pretty}'


def _duplicate(name: str, city: str, exclude_id: int | None = None) -> bool:
    title = name.casefold()
    place = city.casefold()
    rows = University.objects.all()
    if exclude_id is not None:
        rows = rows.exclude(pk=exclude_id)
    return any(row.name_ru.casefold() == title and row.city.casefold() == place for row in rows.only('name_ru', 'city'))


def _website(value: str) -> str:
    raw = (value or '').strip()
    if not raw:
        return ''
    if not (raw.startswith('https://') or raw.startswith('http://')):
        raise serializers.ValidationError({'website': 'Use http:// or https://'})
    return raw[:255]


class StaffUniversitySerializer(serializers.ModelSerializer):
    nameRu = serializers.CharField(source='name_ru')
    nameUz = serializers.CharField(source='name_uz', required=False, allow_blank=True)
    nameEn = serializers.CharField(source='name_en', required=False, allow_blank=True)
    costUsd = serializers.IntegerField(source='cost_usd', min_value=0, required=False)
    programCount = serializers.SerializerMethodField()

    class Meta:
        model = University
        fields = ['id', 'nameRu', 'nameUz', 'nameEn', 'city', 'rating', 'costUsd', 'website', 'programCount']

    def get_programCount(self, obj) -> int:
        return getattr(obj, 'program_count', None) if getattr(obj, 'program_count', None) is not None else obj.programs.count()

    def validate_website(self, value):
        return _website(value)

    def update(self, instance, validated_data):
        if 'cost_usd' in validated_data:
            amount = int(validated_data['cost_usd'])
            instance.cost_ru, instance.cost_uz, instance.cost_en = _money(amount)
            instance.grant_friendly = 0 < amount <= 1000
        name = validated_data.get('name_ru')
        if name and not validated_data.get('name_uz'):
            validated_data['name_uz'] = instance.name_uz or name
        if name and not validated_data.get('name_en'):
            validated_data['name_en'] = instance.name_en or name
        city = validated_data.get('city', instance.city)
        title = validated_data.get('name_ru', instance.name_ru)
        if _duplicate(title, city, instance.pk):
            raise serializers.ValidationError({'nameRu': 'duplicate'})
        return super().update(instance, validated_data)


class StaffUserSerializer(serializers.ModelSerializer):
    isStaff = serializers.BooleanField(source='is_staff', read_only=True)
    email = serializers.SerializerMethodField()
    phone = serializers.SerializerMethodField()
    joinedAt = serializers.DateTimeField(source='date_joined', read_only=True)

    class Meta:
        model = User
        fields = ['id', 'name', 'email', 'phone', 'isStaff', 'is_active', 'joinedAt']

    def get_email(self, obj):
        return obj.email or None

    def get_phone(self, obj):
        return obj.phone or None


class StaffCommentSerializer(serializers.ModelSerializer):
    at = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = ['id', 'name', 'text', 'at', 'is_approved']

    def get_at(self, obj: Comment) -> int:
        return obj.at


class StaffOverviewView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        recent_users = StaffUserSerializer(
            User.objects.order_by('-date_joined')[:8],
            many=True,
        ).data
        recent_comments = StaffCommentSerializer(Comment.objects.all()[:8], many=True).data
        return Response({
            'universities': University.objects.count(),
            'programs': Program.objects.count(),
            'scholarships': Scholarship.objects.count(),
            'users': User.objects.count(),
            'comments': Comment.objects.count(),
            'published': None,
            'recentUsers': recent_users,
            'recentComments': recent_comments,
        })


class StaffUniversityListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = University.objects.annotate(program_count=Count('programs')).order_by('id')
        return Response(StaffUniversitySerializer(qs, many=True).data)

    def post(self, request):
        name = str(request.data.get('nameRu') or '').strip()
        city = str(request.data.get('city') or '').strip()
        if not name or not city:
            return Response({'detail': 'name and city are required'}, status=400)
        if _duplicate(name, city):
            return Response({'detail': 'duplicate'}, status=400)
        try:
            website = _website(str(request.data.get('website') or ''))
            amount = int(request.data.get('costUsd') or 0)
        except (TypeError, ValueError, serializers.ValidationError) as exc:
            detail = getattr(exc, 'detail', None) or 'invalid'
            return Response({'detail': detail}, status=400)
        if amount < 0:
            return Response({'detail': 'cost'}, status=400)
        cost_ru, cost_uz, cost_en = _money(amount)
        next_id = (University.objects.order_by('-id').values_list('id', flat=True).first() or 0) + 1
        uni = University.objects.create(
            id=next_id,
            name_ru=name[:255],
            name_uz=(str(request.data.get('nameUz') or name))[:255],
            name_en=(str(request.data.get('nameEn') or name))[:255],
            city=city[:120],
            rating=str(request.data.get('rating') or '')[:16],
            cost_usd=amount,
            cost_ru=cost_ru,
            cost_uz=cost_uz,
            cost_en=cost_en,
            website=website,
            grant_friendly=0 < amount <= 1000,
        )
        return Response(StaffUniversitySerializer(uni).data, status=status.HTTP_201_CREATED)


class StaffUniversityUpdateView(APIView):
    permission_classes = [IsAdminUser]

    def patch(self, request, uni_id: int):
        uni = University.objects.filter(pk=uni_id).first()
        if uni is None:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        ser = StaffUniversitySerializer(uni, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(ser.data)

    def delete(self, request, uni_id: int):
        uni = University.objects.filter(pk=uni_id).first()
        if uni is None:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        uni.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class StaffCommentListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = Comment.objects.all()[:80]
        return Response(StaffCommentSerializer(qs, many=True).data)


class StaffCommentDeleteView(APIView):
    permission_classes = [IsAdminUser]

    def delete(self, request, comment_id: str):
        deleted, _ = Comment.objects.filter(pk=comment_id).delete()
        if not deleted:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        return Response(status=status.HTTP_204_NO_CONTENT)


class StaffUserListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = User.objects.all().order_by('-date_joined')[:200]
        return Response(StaffUserSerializer(qs, many=True).data)


class StaffUserUpdateView(APIView):
    permission_classes = [IsAdminUser]

    def patch(self, request, user_id: int):
        if request.user.id == user_id:
            return Response({'detail': 'self'}, status=400)
        blocked = {'password', 'is_superuser', 'isSuperuser'}
        if blocked.intersection(request.data.keys()):
            return Response({'detail': 'forbidden field'}, status=400)
        target = User.objects.filter(pk=user_id).first()
        if target is None:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        if 'is_active' in request.data:
            active = bool(request.data.get('is_active'))
            if not active and target.is_staff and not User.objects.filter(is_staff=True, is_active=True).exclude(pk=target.pk).exists():
                return Response({'detail': 'last staff'}, status=400)
            target.is_active = active
        if 'isStaff' in request.data or 'is_staff' in request.data:
            staff = bool(request.data.get('isStaff', request.data.get('is_staff')))
            if target.is_staff and not staff and not User.objects.filter(is_staff=True).exclude(pk=target.pk).exists():
                return Response({'detail': 'last staff'}, status=400)
            target.is_staff = staff
            if not staff:
                target.is_superuser = False
        target.save()
        return Response(StaffUserSerializer(target).data)


class StaffScholarshipListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        rows = Scholarship.objects.all().order_by('id')
        return Response([
            {
                'id': row.id,
                'title': row.title,
                'country': row.country,
                'amount': row.amount,
                'deadline': row.deadline,
                'eligibility': row.eligibility,
                'to': row.to,
            }
            for row in rows
        ])


class StaffScholarshipUpdateView(APIView):
    permission_classes = [IsAdminUser]

    def patch(self, request, scholarship_id: str):
        row = Scholarship.objects.filter(pk=scholarship_id).first()
        if row is None:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)
        limits = {'title': 255, 'country': 120, 'amount': 120, 'deadline': 64, 'eligibility': 255, 'to': 255}
        for field, limit in limits.items():
            if field in request.data:
                setattr(row, field, str(request.data.get(field) or '')[:limit])
        row.save()
        return Response({
            'id': row.id,
            'title': row.title,
            'country': row.country,
            'amount': row.amount,
            'deadline': row.deadline,
            'eligibility': row.eligibility,
            'to': row.to,
        })


class StaffInviteCreateView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request):
        raw, invite = create_invite(request.user)
        return Response({
            'invite': raw,
            'expiresAt': invite.expires_at.isoformat(),
            'hours': INVITE_HOURS,
            'path': f'/admin/register?invite={raw}',
        }, status=status.HTTP_201_CREATED)
