from django.urls import path

from .staff_views import (
    StaffCommentDeleteView,
    StaffCommentListView,
    StaffInviteCreateView,
    StaffOverviewView,
    StaffScholarshipListView,
    StaffScholarshipUpdateView,
    StaffUniversityListView,
    StaffUniversityUpdateView,
    StaffUserListView,
    StaffUserUpdateView,
)
from .views import (
    LoginView,
    LogoutView,
    MeView,
    PasswordResetConfirmView,
    PasswordResetRequestView,
    RefreshView,
    AdminRegisterView,
    RegisterView,
    VerifyConfirmView,
    VerifyRequestView,
)

urlpatterns = [
    path('auth/register/', RegisterView.as_view(), name='auth-register'),
    path('auth/admin-register/', AdminRegisterView.as_view(), name='auth-admin-register'),
    path('auth/login/', LoginView.as_view(), name='auth-login'),
    path('auth/logout/', LogoutView.as_view(), name='auth-logout'),
    path('auth/refresh/', RefreshView.as_view(), name='auth-refresh'),
    path('auth/me/', MeView.as_view(), name='auth-me'),
    path('auth/verify/request/', VerifyRequestView.as_view(), name='auth-verify-request'),
    path('auth/verify/confirm/', VerifyConfirmView.as_view(), name='auth-verify-confirm'),
    path('auth/password-reset/request/', PasswordResetRequestView.as_view(), name='auth-reset-request'),
    path('auth/password-reset/confirm/', PasswordResetConfirmView.as_view(), name='auth-reset-confirm'),
    path('admin/overview/', StaffOverviewView.as_view(), name='staff-overview'),
    path('admin/universities/', StaffUniversityListView.as_view(), name='staff-unis'),
    path('admin/universities/<int:uni_id>/', StaffUniversityUpdateView.as_view(), name='staff-uni'),
    path('admin/comments/', StaffCommentListView.as_view(), name='staff-comments'),
    path('admin/comments/<str:comment_id>/', StaffCommentDeleteView.as_view(), name='staff-comment-delete'),
    path('admin/users/', StaffUserListView.as_view(), name='staff-users'),
    path('admin/users/<int:user_id>/', StaffUserUpdateView.as_view(), name='staff-user'),
    path('admin/scholarships/', StaffScholarshipListView.as_view(), name='staff-scholarships'),
    path('admin/scholarships/<str:scholarship_id>/', StaffScholarshipUpdateView.as_view(), name='staff-scholarship'),
    path('admin/invites/', StaffInviteCreateView.as_view(), name='staff-invites'),
]
