import hashlib
import secrets
from datetime import timedelta

from django.conf import settings
from django.core.cache import cache
from django.core.mail import send_mail
from django.utils import timezone

from .lockout import client_ip
from .models import User, VerificationCode
from .sms import get_sms_provider

CODE_TTL = timedelta(minutes=5)
MAX_ATTEMPTS = 5
GENERIC_OK = {'ok': True}


def hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def _send_allowed(request, target: str) -> bool:
    ip = client_ip(request)
    ip_key = 'verify-ip:' + hashlib.sha256(ip.encode()).hexdigest()
    target_key = 'verify-target:' + hashlib.sha256(target.encode()).hexdigest()
    ip_n = cache.get(ip_key, 0)
    target_n = cache.get(target_key, 0)
    if ip_n >= 10 or target_n >= 3:
        return False
    cache.set(ip_key, ip_n + 1, 3600)
    cache.set(target_key, target_n + 1, 900)
    return True


def issue_code(request, purpose: str, target: str, user: User | None) -> bool:
    """Always returns True to the caller when we must not reveal whether the target exists."""
    if not _send_allowed(request, target):
        return True
    if user is None:
        return True
    code = f'{secrets.randbelow(1_000_000):06d}'
    VerificationCode.objects.filter(purpose=purpose, target=target, expires_at__gt=timezone.now()).delete()
    VerificationCode.objects.create(
        purpose=purpose,
        target=target,
        code_hash=hash_code(code),
        expires_at=timezone.now() + CODE_TTL,
    )
    if purpose == VerificationCode.PURPOSE_EMAIL:
        link = f'{settings.SITE_URL}/profile?verifyEmail={code}&email={target}'
        send_mail(
            'UniSearch — confirm your email',
            f'Confirm your email within 5 minutes: {link}\nCode: {code}',
            settings.DEFAULT_FROM_EMAIL,
            [target],
            fail_silently=True,
        )
    elif purpose == VerificationCode.PURPOSE_RESET:
        if user.phone and user.is_phone_verified:
            get_sms_provider().send(user.phone, f'UniSearch reset code: {code}')
        elif user.email and user.is_email_verified:
            send_mail(
                'UniSearch — password reset',
                f'Reset code (5 minutes): {code}',
                settings.DEFAULT_FROM_EMAIL,
                [user.email],
                fail_silently=True,
            )
    else:
        get_sms_provider().send(target, f'UniSearch code: {code}')
    return True


def check_code(purpose: str, target: str, code: str) -> VerificationCode | None:
    row = (
        VerificationCode.objects.filter(purpose=purpose, target=target)
        .order_by('-created_at')
        .first()
    )
    if row is None or row.expires_at < timezone.now() or row.attempts >= MAX_ATTEMPTS:
        return None
    if row.code_hash != hash_code(code.strip()):
        row.attempts += 1
        row.save(update_fields=['attempts'])
        return None
    row.delete()
    return row
