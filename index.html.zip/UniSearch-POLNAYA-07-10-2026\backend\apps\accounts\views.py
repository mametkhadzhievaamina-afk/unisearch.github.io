from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from rest_framework.exceptions import ValidationError

from apps.common.throttles import LoginThrottle, RefreshThrottle, RegisterThrottle, VerifySendThrottle

from .invites import consume_invite
from .lockout import clear_failures, is_locked, register_failure
from .models import User, VerificationCode
from .serializers import LoginSerializer, RegisterSerializer, UserSerializer, tokens_for, to_e164_uz
from .verification import GENERIC_OK, check_code, issue_code

PRIVILEGE_FIELDS = {'is_staff', 'isStaff', 'is_superuser', 'isSuperuser', 'role', 'is_active', 'isActive'}


def reject_privilege_fields(data):
    if isinstance(data, dict) and PRIVILEGE_FIELDS.intersection(data):
        return Response({'detail': 'Role cannot be changed from this request.'}, status=status.HTTP_400_BAD_REQUEST)
    return None


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [RegisterThrottle]

    def post(self, request):
        blocked = reject_privilege_fields(request.data)
        if blocked:
            return blocked
        ser = RegisterSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = ser.save()
        user.is_staff = False
        user.is_superuser = False
        user.save(update_fields=['is_staff', 'is_superuser'])
        return Response(tokens_for(user), status=status.HTTP_201_CREATED)


class AdminRegisterView(APIView):
    """Staff registration. The invite token is checked on the server; the URL alone grants nothing."""

    permission_classes = [AllowAny]
    throttle_classes = [RegisterThrottle]

    def post(self, request):
        blocked = reject_privilege_fields(request.data)
        if blocked:
            return blocked
        ser = RegisterSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        from django.db import transaction

        with transaction.atomic():
            user = ser.save()
            user.is_staff = True
            user.is_superuser = False
            user.save(update_fields=['is_staff', 'is_superuser'])
            if not consume_invite(str(request.data.get('invite') or ''), user):
                transaction.set_rollback(True)
                return Response(
                    {'invite': 'Invitation is missing, expired, or already used.'},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        return Response(tokens_for(user), status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [LoginThrottle]

    def post(self, request):
        raw_login = str(request.data.get('login') or request.data.get('email') or request.data.get('phone') or '')
        if is_locked(request, raw_login):
            return Response({'detail': 'Wrong login or password.'}, status=status.HTTP_429_TOO_MANY_REQUESTS)
        ser = LoginSerializer(data=request.data)
        try:
            ser.is_valid(raise_exception=True)
        except ValidationError:
            register_failure(request, raw_login)
            return Response({'detail': 'Wrong login or password.'}, status=status.HTTP_400_BAD_REQUEST)
        clear_failures(request, raw_login)
        return Response(tokens_for(ser.validated_data['user']))


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh = request.data.get('refresh')
        if refresh:
            try:
                token = RefreshToken(refresh)
                token.blacklist()
            except Exception:  # noqa: BLE001
                pass
        return Response({'ok': True})


class MeView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        blocked = reject_privilege_fields(request.data)
        if blocked:
            return blocked
        return super().update(request, *args, **kwargs)


class RefreshView(TokenRefreshView):
    permission_classes = [AllowAny]
    throttle_classes = [RefreshThrottle]


class VerifyRequestView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [VerifySendThrottle]

    def post(self, request):
        channel = str(request.data.get('channel') or '').strip()
        target = str(request.data.get('target') or '').strip()
        if channel == 'phone':
            phone = to_e164_uz(target)
            user = User.objects.filter(phone=phone).first() if phone else None
            if phone:
                issue_code(request, VerificationCode.PURPOSE_PHONE, phone, user)
        elif channel == 'email':
            email = target.lower()
            user = User.objects.filter(email__iexact=email).first()
            issue_code(request, VerificationCode.PURPOSE_EMAIL, email, user)
        return Response(GENERIC_OK)


class VerifyConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        channel = str(request.data.get('channel') or '').strip()
        target = str(request.data.get('target') or '').strip()
        code = str(request.data.get('code') or '').strip()
        if channel == 'phone':
            target = to_e164_uz(target) or target
            purpose = VerificationCode.PURPOSE_PHONE
            user = User.objects.filter(phone=target).first()
        else:
            target = target.lower()
            purpose = VerificationCode.PURPOSE_EMAIL
            user = User.objects.filter(email__iexact=target).first()
        if check_code(purpose, target, code) is None or user is None:
            return Response({'detail': 'Invalid or expired code.'}, status=status.HTTP_400_BAD_REQUEST)
        if channel == 'phone':
            user.is_phone_verified = True
            user.save(update_fields=['is_phone_verified'])
        else:
            user.is_email_verified = True
            user.save(update_fields=['is_email_verified'])
        return Response(GENERIC_OK)


class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [VerifySendThrottle]

    def post(self, request):
        target = str(request.data.get('target') or request.data.get('login') or '').strip()
        phone = to_e164_uz(target)
        user = None
        purpose_target = target.lower()
        if phone:
            user = User.objects.filter(phone=phone, is_phone_verified=True).first()
            purpose_target = phone
        if user is None and '@' in target:
            user = User.objects.filter(email__iexact=target.lower(), is_email_verified=True).first()
            purpose_target = target.lower()
        issue_code(request, VerificationCode.PURPOSE_RESET, purpose_target, user)
        return Response(GENERIC_OK)


class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        target = str(request.data.get('target') or request.data.get('login') or '').strip()
        code = str(request.data.get('code') or '').strip()
        password = str(request.data.get('password') or '')
        if len(password) < 8:
            return Response({'password': 'Password must be at least 8 characters.'}, status=status.HTTP_400_BAD_REQUEST)
        phone = to_e164_uz(target)
        lookup = phone or target.lower()
        user = None
        if phone:
            user = User.objects.filter(phone=phone).first()
        if user is None:
            user = User.objects.filter(email__iexact=target.lower()).first()
        if user is None or check_code(VerificationCode.PURPOSE_RESET, lookup, code) is None:
            return Response({'detail': 'Invalid or expired code.'}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(password)
        user.save(update_fields=['password'])
        return Response(GENERIC_OK)
