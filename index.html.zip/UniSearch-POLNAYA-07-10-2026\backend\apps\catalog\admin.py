from django.contrib import admin

from .models import Program, Scholarship, University


@admin.register(University)
class UniversityAdmin(admin.ModelAdmin):
    list_display = ('id', 'name_en', 'city', 'rating', 'cost_usd', 'international')
    list_filter = ('city', 'international', 'needs_ielts', 'grant_friendly')
    search_fields = ('name_ru', 'name_uz', 'name_en', 'city', 'website')


@admin.register(Program)
class ProgramAdmin(admin.ModelAdmin):
    list_display = ('id', 'name_en', 'university', 'grant', 'contract', 'ielts_bonus')
    list_filter = ('ielts_bonus',)
    search_fields = ('id', 'name_ru', 'name_uz', 'name_en')
    raw_id_fields = ('university',)


@admin.register(Scholarship)
class ScholarshipAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'country', 'amount', 'deadline')
    search_fields = ('title', 'eligibility')
