import json
from pathlib import Path

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.catalog.models import Program, Scholarship, University

FIX = Path(__file__).resolve().parents[2] / 'fixtures'


class Command(BaseCommand):
    help = 'Load universities/programs/scholarships from fixtures exported from the frontend'

    def add_arguments(self, parser):
        parser.add_argument('--clear', action='store_true', help='Delete existing catalog rows first')

    @transaction.atomic
    def handle(self, *args, **options):
        if options['clear']:
            Program.objects.all().delete()
            Scholarship.objects.all().delete()
            University.objects.all().delete()
            self.stdout.write('Cleared catalog tables')

        unis = json.loads((FIX / 'universities.json').read_text(encoding='utf-8'))
        programs = json.loads((FIX / 'programs.json').read_text(encoding='utf-8'))
        scholarships = json.loads((FIX / 'scholarships.json').read_text(encoding='utf-8'))

        uni_objs = []
        for u in unis:
            uni_objs.append(
                University(
                    id=u['id'],
                    name_ru=u.get('nameRu', ''),
                    name_uz=u.get('nameUz', ''),
                    name_en=u.get('nameEn', ''),
                    city=u.get('city', ''),
                    cost_ru=u.get('costRu', ''),
                    cost_uz=u.get('costUz', ''),
                    cost_en=u.get('costEn', ''),
                    cost_usd=int(u.get('costUsd') or 0),
                    rating=str(u.get('rating', '')),
                    subjects_ru=u.get('subjectsRu', ''),
                    subjects_uz=u.get('subjectsUz', ''),
                    subjects_en=u.get('subjectsEn', ''),
                    exams_date_ru=u.get('examsDateRu', ''),
                    exams_date_uz=u.get('examsDateUz', ''),
                    exams_date_en=u.get('examsDateEn', ''),
                    description_ru=u.get('descriptionRu', ''),
                    description_uz=u.get('descriptionUz', ''),
                    description_en=u.get('descriptionEn', ''),
                    img=u.get('img', ''),
                    founded=u.get('founded', ''),
                    students=u.get('students', ''),
                    faculties_ru=u.get('facultiesRu', ''),
                    faculties_uz=u.get('facultiesUz', ''),
                    faculties_en=u.get('facultiesEn', ''),
                    admission_ru=u.get('admissionRu', ''),
                    admission_uz=u.get('admissionUz', ''),
                    admission_en=u.get('admissionEn', ''),
                    scholarships_ru=u.get('scholarshipsRu', ''),
                    scholarships_uz=u.get('scholarshipsUz', ''),
                    scholarships_en=u.get('scholarshipsEn', ''),
                    address_ru=u.get('addressRu', ''),
                    address_uz=u.get('addressUz', ''),
                    address_en=u.get('addressEn', ''),
                    phone=u.get('phone') or '',
                    email=u.get('email') or '',
                    website=u.get('website') or '',
                    international=bool(u.get('international')),
                    needs_ielts=bool(u.get('needsIelts')),
                    grant_friendly=bool(u.get('grantFriendly')),
                )
            )
        University.objects.bulk_create(uni_objs, update_conflicts=True, unique_fields=['id'], update_fields=[
            'name_ru', 'name_uz', 'name_en', 'city', 'cost_ru', 'cost_uz', 'cost_en', 'cost_usd',
            'rating', 'subjects_ru', 'subjects_uz', 'subjects_en',
            'exams_date_ru', 'exams_date_uz', 'exams_date_en',
            'description_ru', 'description_uz', 'description_en',
            'img', 'founded', 'students',
            'faculties_ru', 'faculties_uz', 'faculties_en',
            'admission_ru', 'admission_uz', 'admission_en',
            'scholarships_ru', 'scholarships_uz', 'scholarships_en',
            'address_ru', 'address_uz', 'address_en',
            'phone', 'email', 'website', 'international', 'needs_ielts', 'grant_friendly',
        ])

        known_uni_ids = set(University.objects.values_list('id', flat=True))
        prog_objs = []
        skipped = 0
        for p in programs:
            uni_id = p['uniId']
            if uni_id not in known_uni_ids:
                skipped += 1
                continue
            prog_objs.append(
                Program(
                    id=p['id'],
                    university_id=uni_id,
                    name_ru=p.get('nameRu', ''),
                    name_uz=p.get('nameUz', ''),
                    name_en=p.get('nameEn', ''),
                    grant=int(p['grant']),
                    contract=int(p['contract']),
                    ielts_bonus=bool(p.get('ieltsBonus')),
                )
            )
        Program.objects.bulk_create(prog_objs, update_conflicts=True, unique_fields=['id'], update_fields=[
            'university_id', 'name_ru', 'name_uz', 'name_en', 'grant', 'contract', 'ielts_bonus',
        ])

        Scholarship.objects.bulk_create(
            [
                Scholarship(
                    id=s['id'],
                    title=s.get('title', ''),
                    country=s.get('country', ''),
                    amount=s.get('amount', ''),
                    deadline=s.get('deadline', ''),
                    eligibility=s.get('eligibility', ''),
                    to=s.get('to', ''),
                )
                for s in scholarships
            ],
            update_conflicts=True,
            unique_fields=['id'],
            update_fields=['title', 'country', 'amount', 'deadline', 'eligibility', 'to'],
        )

        self.stdout.write(self.style.SUCCESS(
            f'Seeded universities={University.objects.count()} '
            f'programs={Program.objects.count()} (skipped {skipped}) '
            f'scholarships={Scholarship.objects.count()}'
        ))
