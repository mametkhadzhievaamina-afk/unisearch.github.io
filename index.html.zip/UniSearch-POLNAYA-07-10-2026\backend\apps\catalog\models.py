from django.db import models


class University(models.Model):
    """Mirrors frontend `University` in src/types.ts (+ costUsd for filters)."""

    id = models.PositiveIntegerField(primary_key=True)
    name_ru = models.CharField(max_length=255)
    name_uz = models.CharField(max_length=255)
    name_en = models.CharField(max_length=255)
    city = models.CharField(max_length=120, db_index=True)
    cost_ru = models.CharField(max_length=120)
    cost_uz = models.CharField(max_length=120)
    cost_en = models.CharField(max_length=120)
    cost_usd = models.PositiveIntegerField(default=0, db_index=True)
    rating = models.CharField(max_length=16, db_index=True)
    subjects_ru = models.TextField(blank=True, default='')
    subjects_uz = models.TextField(blank=True, default='')
    subjects_en = models.TextField(blank=True, default='')
    exams_date_ru = models.CharField(max_length=255, blank=True, default='')
    exams_date_uz = models.CharField(max_length=255, blank=True, default='')
    exams_date_en = models.CharField(max_length=255, blank=True, default='')
    description_ru = models.TextField(blank=True, default='')
    description_uz = models.TextField(blank=True, default='')
    description_en = models.TextField(blank=True, default='')
    img = models.CharField(max_length=255, blank=True, default='')
    founded = models.CharField(max_length=32, blank=True, default='')
    students = models.CharField(max_length=64, blank=True, default='')
    faculties_ru = models.TextField(blank=True, default='')
    faculties_uz = models.TextField(blank=True, default='')
    faculties_en = models.TextField(blank=True, default='')
    admission_ru = models.TextField(blank=True, default='')
    admission_uz = models.TextField(blank=True, default='')
    admission_en = models.TextField(blank=True, default='')
    scholarships_ru = models.TextField(blank=True, default='')
    scholarships_uz = models.TextField(blank=True, default='')
    scholarships_en = models.TextField(blank=True, default='')
    address_ru = models.TextField(blank=True, default='')
    address_uz = models.TextField(blank=True, default='')
    address_en = models.TextField(blank=True, default='')
    phone = models.CharField(max_length=64, blank=True, default='')
    email = models.CharField(max_length=120, blank=True, default='')
    website = models.CharField(max_length=255, blank=True, default='')
    international = models.BooleanField(default=False)
    needs_ielts = models.BooleanField(default=False)
    grant_friendly = models.BooleanField(default=False)

    class Meta:
        ordering = ['id']
        verbose_name_plural = 'universities'

    def __str__(self) -> str:
        return self.name_en or self.name_ru


class Program(models.Model):
    """Mirrors frontend `Program` — string slug id, uniId FK."""

    id = models.CharField(max_length=64, primary_key=True)
    university = models.ForeignKey(
        University,
        on_delete=models.CASCADE,
        related_name='programs',
        db_column='uni_id',
    )
    name_ru = models.CharField(max_length=255)
    name_uz = models.CharField(max_length=255)
    name_en = models.CharField(max_length=255)
    grant = models.PositiveIntegerField()
    contract = models.PositiveIntegerField()
    ielts_bonus = models.BooleanField(default=False)

    class Meta:
        ordering = ['id']

    def __str__(self) -> str:
        return self.name_en or self.id


class Scholarship(models.Model):
    """Mirrors frontend scholarships.ts entries."""

    id = models.CharField(max_length=64, primary_key=True)
    title = models.CharField(max_length=255)
    country = models.CharField(max_length=120)
    amount = models.CharField(max_length=120)
    deadline = models.CharField(max_length=64)
    eligibility = models.CharField(max_length=255)
    to = models.CharField(max_length=255)

    class Meta:
        ordering = ['id']

    def __str__(self) -> str:
        return self.title
