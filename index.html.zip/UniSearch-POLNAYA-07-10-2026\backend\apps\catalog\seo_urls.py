from django.conf import settings
from django.http import HttpResponse
from django.urls import path

from .models import University


def _abs(path: str) -> str:
    return f'{settings.SITE_URL}{path}'


def university_html(request, uni_id: int):
    uni = University.objects.filter(pk=uni_id).first()
    if uni is None:
        return HttpResponse('Not found', status=404, content_type='text/plain')
    lang = (request.GET.get('lang') or 'ru').lower()
    if lang not in {'ru', 'uz', 'en'}:
        lang = 'ru'
    name = {'ru': uni.name_ru, 'uz': uni.name_uz, 'en': uni.name_en}[lang]
    desc = {'ru': uni.description_ru, 'uz': uni.description_uz, 'en': uni.description_en}[lang]
    path = f'/university/{uni.id}'
    canonical = _abs(path)
    image = _abs(uni.img or '/campus-uz.webp')
    html = f"""<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<title>{_esc(name)} — UniSearch</title>
<meta name="description" content="{_esc(desc[:180])}">
<link rel="canonical" href="{canonical}">
<link rel="alternate" hreflang="ru" href="{canonical}?lang=ru">
<link rel="alternate" hreflang="uz" href="{canonical}?lang=uz">
<link rel="alternate" hreflang="en" href="{canonical}?lang=en">
<meta property="og:type" content="website">
<meta property="og:title" content="{_esc(name)}">
<meta property="og:description" content="{_esc(desc[:180])}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{image}">
<script type="application/ld+json">{{"@context":"https://schema.org","@type":"CollegeOrUniversity","name":"{_esc(name)}","url":"{canonical}","address":"{_esc(uni.city)}"}}</script>
</head>
<body>
<h1>{_esc(name)}</h1>
<p>{_esc(desc)}</p>
<p><a href="{canonical}">UniSearch</a></p>
</body>
</html>"""
    return HttpResponse(html)


def sitemap(request):
    urls = [
        f'<url><loc>{_abs("/")}</loc></url>',
        f'<url><loc>{_abs("/search")}</loc></url>',
        f'<url><loc>{_abs("/top")}</loc></url>',
    ]
    for uni_id in University.objects.values_list('id', flat=True):
        loc = _abs(f'/university/{uni_id}')
        urls.append(
            '<url><loc>{}</loc>'
            '<xhtml:link rel="alternate" hreflang="ru" href="{}?lang=ru"/>'
            '<xhtml:link rel="alternate" hreflang="uz" href="{}?lang=uz"/>'
            '<xhtml:link rel="alternate" hreflang="en" href="{}?lang=en"/>'
            '</url>'.format(loc, loc, loc, loc)
        )
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" '
        'xmlns:xhtml="http://www.w3.org/1999/xhtml">'
        + ''.join(urls) + '</urlset>'
    )
    return HttpResponse(body, content_type='application/xml')


def robots(request):
    text = f'User-agent: *\nAllow: /\nSitemap: {_abs("/sitemap.xml")}\n'
    return HttpResponse(text, content_type='text/plain')


def _esc(value: str) -> str:
    return (
        (value or '')
        .replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
    )


urlpatterns = [
    path('seo/university/<int:uni_id>/', university_html, name='seo-university'),
    path('sitemap.xml', sitemap, name='sitemap'),
    path('robots.txt', robots, name='robots'),
]
