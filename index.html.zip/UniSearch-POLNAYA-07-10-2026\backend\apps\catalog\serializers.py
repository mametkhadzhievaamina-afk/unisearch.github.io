from rest_framework import serializers

from .models import Program, Scholarship, University


class UniversitySerializer(serializers.ModelSerializer):
    """CamelCase keys matching frontend `University` type."""

    nameRu = serializers.CharField(source='name_ru')
    nameUz = serializers.CharField(source='name_uz')
    nameEn = serializers.CharField(source='name_en')
    costRu = serializers.CharField(source='cost_ru')
    costUz = serializers.CharField(source='cost_uz')
    costEn = serializers.CharField(source='cost_en')
    subjectsRu = serializers.CharField(source='subjects_ru')
    subjectsUz = serializers.CharField(source='subjects_uz')
    subjectsEn = serializers.CharField(source='subjects_en')
    examsDateRu = serializers.CharField(source='exams_date_ru')
    examsDateUz = serializers.CharField(source='exams_date_uz')
    examsDateEn = serializers.CharField(source='exams_date_en')
    descriptionRu = serializers.CharField(source='description_ru')
    descriptionUz = serializers.CharField(source='description_uz')
    descriptionEn = serializers.CharField(source='description_en')
    facultiesRu = serializers.CharField(source='faculties_ru')
    facultiesUz = serializers.CharField(source='faculties_uz')
    facultiesEn = serializers.CharField(source='faculties_en')
    admissionRu = serializers.CharField(source='admission_ru')
    admissionUz = serializers.CharField(source='admission_uz')
    admissionEn = serializers.CharField(source='admission_en')
    scholarshipsRu = serializers.CharField(source='scholarships_ru')
    scholarshipsUz = serializers.CharField(source='scholarships_uz')
    scholarshipsEn = serializers.CharField(source='scholarships_en')
    addressRu = serializers.CharField(source='address_ru')
    addressUz = serializers.CharField(source='address_uz')
    addressEn = serializers.CharField(source='address_en')

    class Meta:
        model = University
        fields = [
            'id',
            'nameRu', 'nameUz', 'nameEn',
            'city',
            'costRu', 'costUz', 'costEn',
            'rating',
            'subjectsRu', 'subjectsUz', 'subjectsEn',
            'examsDateRu', 'examsDateUz', 'examsDateEn',
            'descriptionRu', 'descriptionUz', 'descriptionEn',
            'img',
            'founded',
            'students',
            'facultiesRu', 'facultiesUz', 'facultiesEn',
            'admissionRu', 'admissionUz', 'admissionEn',
            'scholarshipsRu', 'scholarshipsUz', 'scholarshipsEn',
            'addressRu', 'addressUz', 'addressEn',
            'phone',
            'email',
            'website',
            'international',
        ]


class UniversityDetailSerializer(UniversitySerializer):
    programs = serializers.SerializerMethodField()

    class Meta(UniversitySerializer.Meta):
        fields = UniversitySerializer.Meta.fields + ['programs']

    def get_programs(self, obj: University):
        qs = obj.programs.all()
        return ProgramSerializer(qs, many=True).data


class ProgramSerializer(serializers.ModelSerializer):
    uniId = serializers.IntegerField(source='university_id')
    nameRu = serializers.CharField(source='name_ru')
    nameUz = serializers.CharField(source='name_uz')
    nameEn = serializers.CharField(source='name_en')
    ieltsBonus = serializers.BooleanField(source='ielts_bonus')

    class Meta:
        model = Program
        fields = ['id', 'uniId', 'nameRu', 'nameUz', 'nameEn', 'grant', 'contract', 'ieltsBonus']


class ScholarshipSerializer(serializers.ModelSerializer):
    class Meta:
        model = Scholarship
        fields = ['id', 'title', 'country', 'amount', 'deadline', 'eligibility', 'to']
