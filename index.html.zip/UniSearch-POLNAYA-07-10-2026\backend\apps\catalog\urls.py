from django.urls import path

from .views import (
    ProgramListView,
    ScholarshipListView,
    UniversityDetailView,
    UniversityListView,
)

urlpatterns = [
    path('universities/', UniversityListView.as_view(), name='university-list'),
    path('universities/<int:id>/', UniversityDetailView.as_view(), name='university-detail'),
    path('programs/', ProgramListView.as_view(), name='program-list'),
    path('scholarships/', ScholarshipListView.as_view(), name='scholarship-list'),
]
