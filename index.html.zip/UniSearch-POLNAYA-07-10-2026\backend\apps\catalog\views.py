from django.db.models import FloatField, Q, QuerySet
from django.db.models.functions import Cast
from rest_framework import generics
from rest_framework.permissions import AllowAny

from .models import Program, Scholarship, University
from .serializers import (
    ProgramSerializer,
    ScholarshipSerializer,
    UniversityDetailSerializer,
    UniversitySerializer,
)


def _text_search(qs: QuerySet[University], *terms: str) -> QuerySet[University]:
    q_obj = Q()
    fields = (
        'name_ru', 'name_uz', 'name_en',
        'subjects_ru', 'subjects_uz', 'subjects_en',
        'faculties_ru', 'faculties_uz', 'faculties_en',
        'description_ru', 'description_uz', 'description_en',
        'city',
    )
    for term in terms:
        term_q = Q()
        for field in fields:
            term_q |= Q(**{f'{field}__icontains': term})
        q_obj |= term_q
    return qs.filter(q_obj)


def _apply_university_filters(qs: QuerySet[University], params) -> QuerySet[University]:
    city = (params.get('city') or 'all').strip()
    if city and city != 'all':
        if city == 'Международный':
            qs = qs.filter(Q(city='Международный') | Q(international=True))
        else:
            qs = qs.filter(city=city)

    cost = (params.get('cost') or 'all').strip().lower()
    if cost == 'low':
        qs = qs.filter(cost_usd__gt=0, cost_usd__lte=1000)
    elif cost == 'mid':
        qs = qs.filter(cost_usd__gt=1000, cost_usd__lte=2500)
    elif cost == 'high':
        qs = qs.filter(cost_usd__gt=2500)

    ielts = (params.get('ielts') or 'all').strip().lower()
    if ielts == 'yes':
        qs = qs.filter(needs_ielts=True)
    elif ielts == 'no':
        qs = qs.filter(needs_ielts=False)

    grant = (params.get('grant') or 'all').strip().lower()
    if grant == 'yes':
        qs = qs.filter(grant_friendly=True)
    elif grant == 'no':
        qs = qs.filter(grant_friendly=False)

    field = (params.get('field') or 'all').strip()
    if field and field != 'all':
        qs = qs.filter(
            Q(subjects_ru__icontains=field)
            | Q(subjects_uz__icontains=field)
            | Q(subjects_en__icontains=field)
        )

    q = (params.get('q') or '').strip().lower()
    if q:
        if q in {'it', 'ит'}:
            qs = _text_search(qs, 'it', 'computer', 'компьютер', 'kompyuter', 'информат', 'software')
        elif q == 'business':
            qs = _text_search(qs, 'business', 'бизнес', 'biznes', 'management', 'менедж')
        elif q == 'medicine':
            qs = _text_search(qs, 'medic', 'медицин', 'davolash', 'лечеб')
        else:
            qs = _text_search(qs, q)

    sort = (params.get('sort') or 'rating').strip().lower()
    if sort == 'cost':
        qs = qs.order_by('cost_usd', 'id')
    else:
        # rating is stored as string to match FE; sort numerically like parseFloat
        qs = qs.annotate(_rating_n=Cast('rating', FloatField())).order_by('-_rating_n', 'id')

    return qs


class UniversityListView(generics.ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = UniversitySerializer

    def get_queryset(self):
        return _apply_university_filters(University.objects.all(), self.request.query_params)


class UniversityDetailView(generics.RetrieveAPIView):
    permission_classes = [AllowAny]
    serializer_class = UniversityDetailSerializer
    queryset = University.objects.prefetch_related('programs')
    lookup_field = 'id'


class ProgramListView(generics.ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = ProgramSerializer
    pagination_class = None

    def get_queryset(self):
        qs = Program.objects.select_related('university')
        uni_id = self.request.query_params.get('uni_id') or self.request.query_params.get('uniId')
        if uni_id:
            qs = qs.filter(university_id=uni_id)
        q = (self.request.query_params.get('q') or '').strip()
        if q:
            qs = qs.filter(
                Q(name_ru__icontains=q)
                | Q(name_uz__icontains=q)
                | Q(name_en__icontains=q)
            )
        return qs


class ScholarshipListView(generics.ListAPIView):
    permission_classes = [AllowAny]
    serializer_class = ScholarshipSerializer
    pagination_class = None
    queryset = Scholarship.objects.all()
