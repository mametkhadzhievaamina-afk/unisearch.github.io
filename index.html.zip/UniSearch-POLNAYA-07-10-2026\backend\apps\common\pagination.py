from rest_framework.pagination import PageNumberPagination


class FlexiblePagination(PageNumberPagination):
    """Allow ?page_size= up to 100 so FE can load the full catalog in fewer requests."""

    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100
