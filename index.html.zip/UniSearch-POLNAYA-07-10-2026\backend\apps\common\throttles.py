from rest_framework.throttling import ScopedRateThrottle


class LoginThrottle(ScopedRateThrottle):
    scope = 'login'


class RegisterThrottle(ScopedRateThrottle):
    scope = 'register'


class RefreshThrottle(ScopedRateThrottle):
    scope = 'refresh'


class VerifySendThrottle(ScopedRateThrottle):
    scope = 'verify_send'
