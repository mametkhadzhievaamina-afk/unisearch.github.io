from django.db import connection
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response


@api_view(['GET'])
@permission_classes([AllowAny])
def health(request):
    """Liveness + basic DB connectivity check."""
    db_ok = False
    db_error = None
    try:
        connection.ensure_connection()
        db_ok = connection.is_usable()
    except Exception as exc:  # noqa: BLE001 — health must never raise
        db_error = str(exc)

    status_code = 200 if db_ok else 503
    payload = {
        'status': 'ok' if db_ok else 'degraded',
        'service': 'unisearch-api',
        'database': 'up' if db_ok else 'down',
    }
    if db_error and not db_ok:
        payload['databaseError'] = db_error
    return Response(payload, status=status_code)
