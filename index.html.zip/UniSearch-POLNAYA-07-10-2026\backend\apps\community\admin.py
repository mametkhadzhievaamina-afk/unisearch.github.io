from django.contrib import admin

from .models import Comment


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('name', 'text', 'is_approved', 'report_count', 'created_at')
    list_filter = ('is_approved',)
    search_fields = ('name', 'text')
    actions = ('approve_comments', 'hide_comments')

    @admin.action(description='Approve selected comments')
    def approve_comments(self, request, queryset):
        queryset.update(is_approved=True)

    @admin.action(description='Hide selected comments')
    def hide_comments(self, request, queryset):
        queryset.update(is_approved=False)
