from django.conf import settings
from django.db import models


class Comment(models.Model):
    """Mirrors frontend HomeComment: id, name, text, at."""

    id = models.CharField(max_length=64, primary_key=True)
    name = models.CharField(max_length=40)
    text = models.CharField(max_length=180)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='comments',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    is_approved = models.BooleanField(default=True, db_index=True)
    report_count = models.PositiveIntegerField(default=0)
    ip_hash = models.CharField(max_length=64, blank=True, default='')

    class Meta:
        ordering = ['-created_at']

    @property
    def at(self) -> int:
        return int(self.created_at.timestamp() * 1000)

    def __str__(self) -> str:
        return f'{self.name}: {self.text[:40]}'
