from django.urls import path

from .views import CommentListCreateView, CommentReportView

urlpatterns = [
    path('comments/', CommentListCreateView.as_view(), name='comments'),
    path('comments/<str:comment_id>/report/', CommentReportView.as_view(), name='comment-report'),
]
