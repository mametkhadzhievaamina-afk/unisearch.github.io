import hashlib
import re
import uuid

from datetime import timedelta

from django.conf import settings
from django.utils import timezone
from rest_framework import serializers, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle, UserRateThrottle
from rest_framework.views import APIView

from apps.accounts.lockout import client_ip

from .models import Comment

STOP_WORDS = {'casino', 'viagra', 'казино'}
LINK_RE = re.compile(r'https?://|www\.', re.I)


class CommentBurstThrottle(AnonRateThrottle):
    rate = '20/hour'


class CommentUserThrottle(UserRateThrottle):
    rate = '60/hour'


class CommentBurstThrottle(AnonRateThrottle):
    rate = '20/hour'


class CommentUserThrottle(UserRateThrottle):
    rate = '60/hour'


class CommentSerializer(serializers.ModelSerializer):
    at = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = ['id', 'name', 'text', 'at']

    def get_at(self, obj: Comment) -> int:
        return obj.at


class CommentListCreateView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [CommentBurstThrottle, CommentUserThrottle]

    def get(self, request):
        qs = Comment.objects.filter(is_approved=True)[:40]
        return Response(CommentSerializer(qs, many=True).data)

    def post(self, request):
        if str(request.data.get('company') or '').strip():
            return Response({'id': '0', 'name': 'Guest', 'text': '', 'at': 0}, status=status.HTTP_201_CREATED)
        if not _turnstile_ok(request):
            return Response({'detail': 'Comment could not be posted.'}, status=status.HTTP_400_BAD_REQUEST)
        name = str(request.data.get('name') or '').strip()[:40]
        text = str(request.data.get('text') or '').strip()[:180]
        if not text or _blocked(text):
            return Response({'detail': 'Comment could not be posted.'}, status=status.HTTP_400_BAD_REQUEST)
        if not name:
            name = 'Guest'
        ip = client_ip(request)
        ip_hash = hashlib.sha256(ip.encode()).hexdigest()
        recent = timezone.now() - timedelta(hours=1)
        if Comment.objects.filter(text=text, created_at__gte=recent).exists():
            return Response({'detail': 'Comment could not be posted.'}, status=status.HTTP_400_BAD_REQUEST)
        if Comment.objects.filter(ip_hash=ip_hash, created_at__gte=recent).count() >= 5:
            return Response({'detail': 'Comment could not be posted.'}, status=status.HTTP_429_TOO_MANY_REQUESTS)
        comment = Comment.objects.create(
            id=str(uuid.uuid4()),
            name=name,
            text=text,
            user=request.user if request.user.is_authenticated else None,
            is_approved=False,
            ip_hash=ip_hash,
        )
        old_ids = list(Comment.objects.order_by('-created_at').values_list('id', flat=True)[200:])
        if old_ids:
            Comment.objects.filter(id__in=old_ids).delete()
        return Response(CommentSerializer(comment).data, status=status.HTTP_201_CREATED)


class CommentReportView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [CommentBurstThrottle]

    def post(self, request, comment_id: str):
        comment = Comment.objects.filter(pk=comment_id, is_approved=True).first()
        if comment is None:
            return Response({'ok': True})
        comment.report_count += 1
        if comment.report_count >= 3:
            comment.is_approved = False
        comment.save(update_fields=['report_count', 'is_approved'])
        return Response({'ok': True})


def _blocked(text: str) -> bool:
    low = text.lower()
    if LINK_RE.search(text):
        return True
    return any(word in low for word in STOP_WORDS)


def _turnstile_ok(request) -> bool:
    secret = getattr(settings, 'TURNSTILE_SECRET', '') or ''
    if not secret:
        return True
    token = str(request.data.get('turnstileToken') or '')
    if not token:
        return False
    from urllib import parse, request as urlrequest
    body = parse.urlencode({'secret': secret, 'response': token, 'remoteip': client_ip(request)}).encode()
    try:
        with urlrequest.urlopen(
            urlrequest.Request('https://challenges.cloudflare.com/turnstile/v0/siteverify', data=body, method='POST'),
            timeout=8,
        ) as resp:
            import json
            return bool(json.loads(resp.read().decode()).get('success'))
    except Exception:
        return False
