from django.contrib import admin

from .models import AdmissionPlan, SavedUniversity, TrackEvent, TrackTask, TrackUniversity, UserChecklist


@admin.register(SavedUniversity)
class SavedUniversityAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'university', 'created_at')
    raw_id_fields = ('user', 'university')


@admin.register(AdmissionPlan)
class AdmissionPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'grade', 'admission_year', 'onboarded', 'updated_at')
    raw_id_fields = ('user',)


@admin.register(TrackUniversity)
class TrackUniversityAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'university', 'created_at')
    raw_id_fields = ('user', 'university')


@admin.register(TrackTask)
class TrackTaskAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'category', 'status', 'due_date', 'date_confirmed')
    list_filter = ('category', 'status')
    raw_id_fields = ('user', 'university')


@admin.register(TrackEvent)
class TrackEventAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'kind', 'event_date', 'date_confirmed')
    raw_id_fields = ('user', 'university')


@admin.register(UserChecklist)
class UserChecklistAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'updated_at')
    raw_id_fields = ('user',)
