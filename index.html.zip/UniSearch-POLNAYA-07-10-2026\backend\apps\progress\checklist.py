"""Static checklist template — same ids/labels as frontend/src/data/checklist.ts."""

CHECKLIST_TEMPLATE = [
    {'id': 'docs_passport', 'ru': 'Паспорт / ID', 'uz': 'Pasport / ID', 'en': 'Passport / ID'},
    {'id': 'docs_cert', 'ru': 'Аттестат и приложение', 'uz': 'Attestat va ilova', 'en': 'Certificate & transcript'},
    {'id': 'docs_photo', 'ru': 'Фото 3x4 (6 шт.)', 'uz': '3x4 foto (6 dona)', 'en': '3x4 photos (6 pcs)'},
    {'id': 'ielts', 'ru': 'IELTS / внутренний англ.', 'uz': 'IELTS / ichki ingliz', 'en': 'IELTS / internal English'},
    {'id': 'uni_pick', 'ru': 'Выбрать 3 приоритетных вуза', 'uz': '3 ustuvor OTMni tanlash', 'en': 'Pick 3 priority universities'},
    {'id': 'chance_calc', 'ru': 'Рассчитать шансы', 'uz': 'Imkoniyatni hisoblash', 'en': 'Run chance calculator'},
    {'id': 'apply', 'ru': 'Подать документы в вуз', 'uz': 'OTMga hujjat topshirish', 'en': 'Submit university application'},
    {'id': 'contract', 'ru': 'Грант / контракт решение', 'uz': 'Grant / kontrakt qarori', 'en': 'Grant / contract decision'},
]

TEMPLATE_IDS = {item['id'] for item in CHECKLIST_TEMPLATE}
