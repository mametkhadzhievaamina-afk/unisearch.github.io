from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('progress', '0002_userchecklist'),
    ]

    operations = [
        migrations.DeleteModel(name='DtmHistoryRecord'),
        migrations.RunSQL('DROP TABLE IF EXISTS dtm_dtmattemptresult;', migrations.RunSQL.noop),
        migrations.RunSQL('DROP TABLE IF EXISTS dtm_dtmexamsession;', migrations.RunSQL.noop),
        migrations.RunSQL('DROP TABLE IF EXISTS dtm_dtmtest;', migrations.RunSQL.noop),
        migrations.RunSQL('DROP TABLE IF EXISTS dtm_dtmquestion;', migrations.RunSQL.noop),
    ]
