import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('catalog', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('progress', '0003_delete_dtm_history'),
    ]

    operations = [
        migrations.CreateModel(
            name='AdmissionPlan',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('grade', models.CharField(blank=True, default='', max_length=16)),
                ('major', models.CharField(blank=True, default='', max_length=160)),
                ('admission_year', models.PositiveSmallIntegerField(blank=True, null=True)),
                ('onboarded', models.BooleanField(default=False)),
                ('wizard_step', models.PositiveSmallIntegerField(default=1)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='admission_plan', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='TrackUniversity',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('university', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='tracked_by', to='catalog.university')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='track_universities', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['created_at'], 'unique_together': {('user', 'university')}},
        ),
        migrations.CreateModel(
            name='TrackTask',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('category', models.CharField(choices=[('research', 'research'), ('exam', 'exam'), ('documents', 'documents'), ('application', 'application'), ('scholarship', 'scholarship'), ('final', 'final')], default='research', max_length=20)),
                ('title_ru', models.CharField(max_length=180)),
                ('title_uz', models.CharField(blank=True, default='', max_length=180)),
                ('title_en', models.CharField(blank=True, default='', max_length=180)),
                ('description_ru', models.TextField(blank=True, default='')),
                ('description_uz', models.TextField(blank=True, default='')),
                ('description_en', models.TextField(blank=True, default='')),
                ('due_date', models.DateField(blank=True, null=True)),
                ('date_confirmed', models.BooleanField(default=False)),
                ('priority', models.CharField(choices=[('low', 'low'), ('medium', 'medium'), ('high', 'high')], default='medium', max_length=10)),
                ('status', models.CharField(choices=[('not_started', 'not_started'), ('in_progress', 'in_progress'), ('completed', 'completed')], default='not_started', max_length=20)),
                ('link', models.CharField(blank=True, default='', max_length=255)),
                ('template_key', models.CharField(blank=True, default='', max_length=64)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('university', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='track_tasks', to='catalog.university')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='track_tasks', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['due_date', 'id']},
        ),
        migrations.AddConstraint(
            model_name='tracktask',
            constraint=models.UniqueConstraint(condition=~models.Q(template_key=''), fields=('user', 'template_key'), name='uniq_track_task_template'),
        ),
        migrations.CreateModel(
            name='TrackEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=180)),
                ('note', models.TextField(blank=True, default='')),
                ('kind', models.CharField(choices=[('application', 'application'), ('exam', 'exam'), ('documents', 'documents'), ('scholarship', 'scholarship'), ('study', 'study'), ('custom', 'custom')], default='custom', max_length=20)),
                ('event_date', models.DateField(blank=True, null=True)),
                ('date_confirmed', models.BooleanField(default=False)),
                ('link', models.CharField(blank=True, default='', max_length=255)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('university', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='track_events', to='catalog.university')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='track_events', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['event_date', 'id']},
        ),
    ]
