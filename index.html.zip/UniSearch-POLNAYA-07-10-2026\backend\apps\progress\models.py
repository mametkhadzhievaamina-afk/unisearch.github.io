from django.conf import settings
from django.db import models


class SavedUniversity(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='saved_universities',
    )
    university = models.ForeignKey(
        'catalog.University',
        on_delete=models.CASCADE,
        related_name='saved_by',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'university')
        ordering = ['-created_at']

    def __str__(self) -> str:
        return f'{self.user_id}:{self.university_id}'


class AdmissionPlan(models.Model):
    """One private admission plan per user. Dates are never invented here."""

    GRADE_CHOICES = [
        ('9', '9'),
        ('10', '10'),
        ('11', '11'),
        ('graduate', 'graduate'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='admission_plan',
    )
    grade = models.CharField(max_length=16, blank=True, default='')
    major = models.CharField(max_length=160, blank=True, default='')
    admission_year = models.PositiveSmallIntegerField(null=True, blank=True)
    onboarded = models.BooleanField(default=False)
    wizard_step = models.PositiveSmallIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'plan:{self.user_id}'


class TrackUniversity(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='track_universities',
    )
    university = models.ForeignKey(
        'catalog.University',
        on_delete=models.CASCADE,
        related_name='tracked_by',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'university')
        ordering = ['created_at']

    def __str__(self) -> str:
        return f'{self.user_id}:{self.university_id}'


class TrackTask(models.Model):
    CATEGORIES = [
        ('research', 'research'),
        ('exam', 'exam'),
        ('documents', 'documents'),
        ('application', 'application'),
        ('scholarship', 'scholarship'),
        ('final', 'final'),
    ]
    PRIORITIES = [('low', 'low'), ('medium', 'medium'), ('high', 'high')]
    STATUSES = [
        ('not_started', 'not_started'),
        ('in_progress', 'in_progress'),
        ('completed', 'completed'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='track_tasks',
    )
    university = models.ForeignKey(
        'catalog.University',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='track_tasks',
    )
    category = models.CharField(max_length=20, choices=CATEGORIES, default='research')
    title_ru = models.CharField(max_length=180)
    title_uz = models.CharField(max_length=180, blank=True, default='')
    title_en = models.CharField(max_length=180, blank=True, default='')
    description_ru = models.TextField(blank=True, default='')
    description_uz = models.TextField(blank=True, default='')
    description_en = models.TextField(blank=True, default='')
    due_date = models.DateField(null=True, blank=True)
    date_confirmed = models.BooleanField(default=False)
    priority = models.CharField(max_length=10, choices=PRIORITIES, default='medium')
    status = models.CharField(max_length=20, choices=STATUSES, default='not_started')
    link = models.CharField(max_length=255, blank=True, default='')
    template_key = models.CharField(max_length=64, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['due_date', 'id']
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'template_key'],
                condition=~models.Q(template_key=''),
                name='uniq_track_task_template',
            ),
        ]

    def __str__(self) -> str:
        return f'{self.user_id}:{self.title_en or self.title_ru}'


class TrackEvent(models.Model):
    KINDS = [
        ('application', 'application'),
        ('exam', 'exam'),
        ('documents', 'documents'),
        ('scholarship', 'scholarship'),
        ('study', 'study'),
        ('custom', 'custom'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='track_events',
    )
    university = models.ForeignKey(
        'catalog.University',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='track_events',
    )
    title = models.CharField(max_length=180)
    note = models.TextField(blank=True, default='')
    kind = models.CharField(max_length=20, choices=KINDS, default='custom')
    event_date = models.DateField(null=True, blank=True)
    date_confirmed = models.BooleanField(default=False)
    link = models.CharField(max_length=255, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['event_date', 'id']

    def __str__(self) -> str:
        return f'{self.user_id}:{self.title}'


class UserChecklist(models.Model):
    """Per-user checklist map: { itemId: bool } — matches FE store.checklist."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='checklist',
    )
    items = models.JSONField(default=dict, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'checklist:{self.user_id}'

