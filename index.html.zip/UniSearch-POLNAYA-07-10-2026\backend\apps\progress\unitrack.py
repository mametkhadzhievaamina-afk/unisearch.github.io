"""UniTrack: private admission plans, tasks, events, and rule-based next steps.

Official dates are never invented. Generated tasks have no due date.
Catalog exam and scholarship strings are returned as unconfirmed notes.
"""

from datetime import date, timedelta

from django.shortcuts import get_object_or_404
from rest_framework import serializers, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.catalog.models import Scholarship, University

from .models import AdmissionPlan, TrackEvent, TrackTask, TrackUniversity

CATEGORIES = [c[0] for c in TrackTask.CATEGORIES]
PRIORITIES = [c[0] for c in TrackTask.PRIORITIES]
STATUSES = [c[0] for c in TrackTask.STATUSES]
KINDS = [c[0] for c in TrackEvent.KINDS]
GRADES = [c[0] for c in AdmissionPlan.GRADE_CHOICES]
STAGE_ORDER = ['research', 'exam', 'documents', 'application', 'scholarship', 'final']
MAX_TASKS = 200
MAX_EVENTS = 100
MAX_UNIS = 12
YEAR_MIN = 2024
YEAR_MAX = 2036


def _http_link(value: str) -> str:
    raw = (value or '').strip()
    if raw.startswith('/') and not raw.startswith('//'):
        return raw[:255]
    if raw.startswith('https://') or raw.startswith('http://'):
        return raw[:255]
    return ''


def _filled(*parts: str) -> str:
    return next((p.strip() for p in parts if p and p.strip()), '')


def _tri(ru: str, uz: str, en: str) -> dict:
    return {'ru': ru, 'uz': uz or ru, 'en': en or ru}


def _task_payload(task: TrackTask) -> dict:
    return {
        'id': task.id,
        'universityId': task.university_id,
        'category': task.category,
        'titleRu': task.title_ru,
        'titleUz': task.title_uz or task.title_ru,
        'titleEn': task.title_en or task.title_ru,
        'descriptionRu': task.description_ru,
        'descriptionUz': task.description_uz or task.description_ru,
        'descriptionEn': task.description_en or task.description_ru,
        'dueDate': task.due_date.isoformat() if task.due_date else None,
        'dateConfirmed': task.date_confirmed,
        'priority': task.priority,
        'status': task.status,
        'link': task.link,
        'templateKey': task.template_key,
    }


def _event_payload(event: TrackEvent) -> dict:
    return {
        'id': event.id,
        'universityId': event.university_id,
        'title': event.title,
        'note': event.note,
        'kind': event.kind,
        'eventDate': event.event_date.isoformat() if event.event_date else None,
        'dateConfirmed': event.date_confirmed,
        'link': event.link,
    }


def _uni_payload(row: TrackUniversity) -> dict:
    uni = row.university
    programs = [
        {
            'id': p.id,
            'nameRu': p.name_ru,
            'nameUz': p.name_uz,
            'nameEn': p.name_en,
            'grant': p.grant,
            'contract': p.contract,
        }
        for p in uni.programs.all()
    ]
    return {
        'universityId': uni.id,
        'nameRu': uni.name_ru,
        'nameUz': uni.name_uz,
        'nameEn': uni.name_en,
        'city': uni.city,
        'costRu': uni.cost_ru,
        'costUz': uni.cost_uz,
        'costEn': uni.cost_en,
        'subjectsRu': uni.subjects_ru,
        'subjectsUz': uni.subjects_uz,
        'subjectsEn': uni.subjects_en,
        'examsDateRu': uni.exams_date_ru,
        'examsDateUz': uni.exams_date_uz,
        'examsDateEn': uni.exams_date_en,
        'admissionRu': uni.admission_ru,
        'admissionUz': uni.admission_uz,
        'admissionEn': uni.admission_en,
        'scholarshipsRu': uni.scholarships_ru,
        'scholarshipsUz': uni.scholarships_uz,
        'scholarshipsEn': uni.scholarships_en,
        'website': _http_link(uni.website),
        'programs': programs,
    }


def _stage(tasks: list[TrackTask]) -> str:
    if not tasks:
        return 'research'
    for category in STAGE_ORDER:
        own = [t for t in tasks if t.category == category]
        if own and any(t.status != 'completed' for t in own):
            return category
    return 'final'


def _catalog_notes(rows: list[TrackUniversity]) -> list[dict]:
    notes = []
    ids = []
    for row in rows:
        uni = row.university
        ids.append(uni.id)
        exam = _filled(uni.exams_date_ru, uni.exams_date_uz, uni.exams_date_en)
        if exam:
            notes.append({
                'kind': 'exam',
                'confirmed': False,
                'universityId': uni.id,
                'textRu': uni.exams_date_ru,
                'textUz': uni.exams_date_uz or uni.exams_date_ru,
                'textEn': uni.exams_date_en or uni.exams_date_ru,
                'nameRu': uni.name_ru,
                'nameUz': uni.name_uz,
                'nameEn': uni.name_en,
            })
    if not ids:
        return notes
    wanted = {f'/university/{uni_id}' for uni_id in ids}
    for item in Scholarship.objects.filter(to__in=wanted):
        if not (item.deadline or '').strip():
            continue
        notes.append({
            'kind': 'scholarship',
            'confirmed': False,
            'universityId': None,
            'textRu': f'{item.title}: {item.deadline}',
            'textUz': f'{item.title}: {item.deadline}',
            'textEn': f'{item.title}: {item.deadline}',
            'nameRu': item.title,
            'nameUz': item.title,
            'nameEn': item.title,
            'link': item.to if str(item.to).startswith('/') else '',
        })
    return notes


def _recommendations(plan: AdmissionPlan | None, rows: list[TrackUniversity], tasks: list[TrackTask], events: list[TrackEvent]) -> list[dict]:
    if plan is None or not plan.onboarded:
        return [{'code': 'start_onboarding'}]
    out: list[dict] = []
    today = date.today()
    week_end = today + timedelta(days=7)
    due_week = [
        t for t in tasks
        if t.due_date and t.date_confirmed and t.status != 'completed' and today <= t.due_date <= week_end
    ]
    overdue = [
        t for t in tasks
        if t.due_date and t.date_confirmed and t.status != 'completed' and t.due_date < today
    ]
    if overdue:
        out.append({'code': 'overdue', 'count': len(overdue)})
    if due_week:
        out.append({'code': 'tasks_due_week', 'count': len(due_week)})
    if not rows:
        out.append({'code': 'no_universities'})
    if not (plan.major or '').strip():
        out.append({'code': 'choose_major'})
    if plan.admission_year is None:
        out.append({'code': 'choose_year'})
    exam_open = not any(t.category == 'exam' and t.status != 'not_started' for t in tasks) and not any(
        e.kind == 'exam' and e.event_date for e in events
    )
    if exam_open:
        out.append({'code': 'add_exam_schedule'})
    for row in rows:
        uni = row.university
        req = next((t for t in tasks if t.template_key == f'uni-{uni.id}-requirements'), None)
        if req is None or req.status != 'completed':
            out.append({
                'code': 'check_requirements',
                'universityId': uni.id,
                'nameRu': uni.name_ru,
                'nameUz': uni.name_uz,
                'nameEn': uni.name_en,
            })
        grants = _filled(uni.scholarships_ru, uni.scholarships_uz, uni.scholarships_en)
        grant_task = next((t for t in tasks if t.template_key == f'uni-{uni.id}-grants'), None)
        if grants and (grant_task is None or grant_task.status != 'completed'):
            out.append({
                'code': 'check_grants',
                'universityId': uni.id,
                'nameRu': uni.name_ru,
                'nameUz': uni.name_uz,
                'nameEn': uni.name_en,
            })
        if len(out) >= 6:
            break
    return out[:6]


def _snapshot(user) -> dict:
    plan = AdmissionPlan.objects.filter(user=user).first()
    rows = list(
        TrackUniversity.objects.filter(user=user).select_related('university').prefetch_related('university__programs')
    )
    tasks = list(TrackTask.objects.filter(user=user))
    events = list(TrackEvent.objects.filter(user=user))
    completed = sum(1 for t in tasks if t.status == 'completed')
    return {
        'plan': None if plan is None else {
            'grade': plan.grade,
            'major': plan.major,
            'admissionYear': plan.admission_year,
            'onboarded': plan.onboarded,
            'wizardStep': plan.wizard_step,
            'stage': _stage(tasks) if plan.onboarded else 'research',
        },
        'universities': [_uni_payload(row) for row in rows],
        'tasks': [_task_payload(t) for t in tasks],
        'events': [_event_payload(e) for e in events],
        'catalogNotes': _catalog_notes(rows),
        'recommendations': _recommendations(plan, rows, tasks, events),
        'progress': {
            'completed': completed,
            'pending': len(tasks) - completed,
            'total': len(tasks),
        },
    }


def _clean_date(value, confirmed_default: bool):
    if value in (None, ''):
        return None, False
    if isinstance(value, date):
        parsed = value
    else:
        try:
            parsed = date.fromisoformat(str(value)[:10])
        except ValueError as exc:
            raise serializers.ValidationError('date') from exc
    return parsed, True if confirmed_default else False


class PlanPatchSerializer(serializers.Serializer):
    grade = serializers.CharField(required=False, allow_blank=True, max_length=16)
    major = serializers.CharField(required=False, allow_blank=True, max_length=160)
    admissionYear = serializers.IntegerField(required=False, allow_null=True, min_value=YEAR_MIN, max_value=YEAR_MAX)
    wizardStep = serializers.IntegerField(required=False, min_value=1, max_value=5)

    def validate_grade(self, value):
        if value and value not in GRADES:
            raise serializers.ValidationError('grade')
        return value


class TaskWriteSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=180)
    description = serializers.CharField(required=False, allow_blank=True, default='')
    category = serializers.ChoiceField(choices=CATEGORIES, default='research')
    priority = serializers.ChoiceField(choices=PRIORITIES, default='medium')
    status = serializers.ChoiceField(choices=STATUSES, default='not_started')
    universityId = serializers.IntegerField(required=False, allow_null=True)
    dueDate = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    link = serializers.CharField(required=False, allow_blank=True, default='', max_length=255)


class TaskPatchSerializer(serializers.Serializer):
    title = serializers.CharField(required=False, max_length=180)
    description = serializers.CharField(required=False, allow_blank=True)
    category = serializers.ChoiceField(choices=CATEGORIES, required=False)
    priority = serializers.ChoiceField(choices=PRIORITIES, required=False)
    status = serializers.ChoiceField(choices=STATUSES, required=False)
    universityId = serializers.IntegerField(required=False, allow_null=True)
    dueDate = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    link = serializers.CharField(required=False, allow_blank=True, max_length=255)


class EventWriteSerializer(serializers.Serializer):
    title = serializers.CharField(max_length=180)
    note = serializers.CharField(required=False, allow_blank=True, default='')
    kind = serializers.ChoiceField(choices=KINDS, default='custom')
    universityId = serializers.IntegerField(required=False, allow_null=True)
    eventDate = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    link = serializers.CharField(required=False, allow_blank=True, default='', max_length=255)


class GenerateSerializer(serializers.Serializer):
    grade = serializers.CharField(required=False, allow_blank=True, default='', max_length=16)
    major = serializers.CharField(required=False, allow_blank=True, default='', max_length=160)
    admissionYear = serializers.IntegerField(required=False, allow_null=True, min_value=YEAR_MIN, max_value=YEAR_MAX)
    universityIds = serializers.ListField(
        child=serializers.IntegerField(min_value=1),
        required=False,
        default=list,
        max_length=MAX_UNIS,
    )

    def validate_grade(self, value):
        if value and value not in GRADES:
            raise serializers.ValidationError('grade')
        return value


def _owned_university(user, uni_id):
    if uni_id in (None, ''):
        return None
    uni = University.objects.filter(pk=uni_id).first()
    if uni is None:
        raise serializers.ValidationError({'universityId': 'unknown'})
    return uni


CORE_COPY = {
    'core-research': {
        'category': 'research',
        'priority': 'high',
        'link': '/search',
        'title': _tri(
            'Открыть каталог и отобрать вузы',
            "Katalogni ochib, OTMlarni saralash",
            'Open the catalog and shortlist universities',
        ),
        'desc': _tri(
            'В каталоге UniSearch уже есть карточки вузов: город, стоимость, предметы и сайт, если они заполнены. Отметьте задачу, когда выберете хотя бы три варианта. Официальный срок подачи сюда не подставлен.',
            "UniSearch katalogida OTM kartalari bor: shahar, narx, fanlar va sayt, agar to'ldirilgan bo'lsa. Kamida uchta variant tanlagach, vazifani belgilang. Rasmiy muddat qo'yilmagan.",
            'The UniSearch catalog already lists universities, with city, cost, subjects and a website when those fields are filled in. Complete this after you pick at least three. No official deadline is filled in.',
        ),
    },
    'core-compare': {
        'category': 'research',
        'priority': 'medium',
        'link': '/tools',
        'title': _tri(
            'Сравнить отобранные вузы',
            'Tanlangan OTMlarni solishtirish',
            'Compare the universities you picked',
        ),
        'desc': _tri(
            'Откройте сравнение в инструментах. Пустые поля в карточке означают, что в каталоге этих данных нет, а не то, что их нет у вуза.',
            "Vositalardagi solishtirishni oching. Kartadagi bo'sh joy katalogda ma'lumot yo'qligini bildiradi.",
            'Use the comparison in Tools. An empty field means the catalog does not have that fact, not that the university has none.',
        ),
    },
    'core-chance': {
        'category': 'application',
        'priority': 'medium',
        'link': '/chance',
        'title': _tri(
            'Прикинуть шансы на грант и контракт',
            "Grant va kontrakt imkoniyatini hisoblash",
            'Estimate grant and contract chances',
        ),
        'desc': _tri(
            'Калькулятор использует пороги из каталога. Это оценка UniSearch, не решение приёмной комиссии.',
            "Kalkulyator katalogdagi chegaralardan foydalanadi. Bu UniSearch bahosi, qabul komissiyasining qarori emas.",
            'The calculator uses catalog score thresholds. It is a UniSearch estimate, not an admissions decision.',
        ),
    },
    'core-exam': {
        'category': 'exam',
        'priority': 'high',
        'title': _tri(
            'Составить своё расписание подготовки к вступительным',
            'Kirish imtihoniga shaxsiy tayyorgarlik jadvalini tuzish',
            'Build your own entrance-exam study schedule',
        ),
        'desc': _tri(
            'Дата экзамена не подтверждена в UniSearch. Когда найдёте официальное объявление, добавьте событие в календарь сами.',
            "Imtihon sanasi UniSearchda tasdiqlanmagan. Rasmiy e'lonni topsangiz, sanani taqvimga o'zingiz qo'shing.",
            'UniSearch does not have a confirmed exam date. When you find an official notice, add the date to your calendar yourself.',
        ),
    },
    'core-documents': {
        'category': 'documents',
        'priority': 'high',
        'link': '/tools',
        'title': _tri(
            'Собрать паспорт, аттестат и фотографии 3×4',
            "Pasport, attestat va 3×4 fotosuratlarni yig'ish",
            'Collect your passport, certificate and 3×4 photos',
        ),
        'desc': _tri(
            'Это памятка UniSearch, не официальный список вуза. Сверьте её с приёмной комиссией и отметьте задачу, когда пакет собран.',
            "Bu UniSearch eslatmasi, OTMning rasmiy ro'yxati emas. Qabul komissiyasi bilan solishtiring va to'plam tayyor bo'lsa, vazifani belgilang.",
            'This is a UniSearch reminder, not an official university list. Check it with the admissions office and complete the task when the set is ready.',
        ),
    },
    'core-exam-date': {
        'category': 'exam',
        'priority': 'high',
        'title': _tri(
            'Вписать свою дату вступительного экзамена',
            'Kirish imtihonining o‘z sanasini yozish',
            'Enter your own entrance-exam date',
        ),
        'desc': _tri(
            'UniSearch не подставляет официальную дату. Когда найдёте объявление вуза или агентства, добавьте событие в календарь и укажите ссылку на источник.',
            "UniSearch rasmiy sanani qo'ymaydi. OTM yoki agentlik e'lonini topsangiz, taqvimga voqea qo'shing va manba havolasini yozing.",
            'UniSearch does not insert an official date. When you find the university or agency notice, add a calendar event and paste the source link.',
        ),
    },
    'core-application': {
        'category': 'application',
        'priority': 'medium',
        'title': _tri(
            'Уточнить, как подавать документы в выбранные вузы',
            "Tanlangan OTMlarga hujjat qanday topshirilishini aniqlash",
            'Confirm how to apply to each target university',
        ),
        'desc': _tri(
            'Способ и срок подачи зависят от вуза. Не подставляйте дату, пока не проверите официальный источник.',
            "Topshirish usuli va muddati OTMga bog'liq. Rasmiy manbani tekshirmaguncha sana qo'ymang.",
            'The method and deadline depend on the university. Do not enter a date until you have checked an official source.',
        ),
    },
    'core-scholarship': {
        'category': 'scholarship',
        'priority': 'medium',
        'title': _tri(
            'Проверить сведения о грантах в каталоге и на сайтах вузов',
            "Grant ma'lumotlarini katalog va OTM saytlarida tekshirish",
            'Check grant notes in the catalog and on university sites',
        ),
        'desc': _tri(
            'Если в карточке вуза нет текста о гранте, UniSearch это не подтверждает. Смотрите официальный сайт.',
            "OTM kartasida grant matni bo'lmasa, UniSearch buni tasdiqlamaydi. Rasmiy saytni ko'ring.",
            'If a university card has no grant text, UniSearch has not confirmed one. Check the official site.',
        ),
    },
    'core-final': {
        'category': 'final',
        'priority': 'low',
        'title': _tri(
            'Уточнить шаги после публикации результатов',
            "Natijalar e'lon qilingach keyingi qadamlarni aniqlash",
            'Confirm the steps after results are published',
        ),
        'desc': _tri(
            'Зачисление и договор зависят от вуза. Добавьте свою дату, когда она будет объявлена.',
            "Qabul va shartnoma OTMga bog'liq. Sana e'lon qilinganda uni o'zingiz qo'shing.",
            'Enrollment and the contract depend on the university. Add your own date when it is announced.',
        ),
    },
}


def _ensure_task(user, key: str, university, copy: dict, link: str = ''):
    if TrackTask.objects.filter(user=user, template_key=key).exists():
        return
    TrackTask.objects.create(
        user=user,
        university=university,
        category=copy['category'],
        priority=copy['priority'],
        title_ru=copy['title']['ru'][:180],
        title_uz=copy['title']['uz'][:180],
        title_en=copy['title']['en'][:180],
        description_ru=copy['desc']['ru'],
        description_uz=copy['desc']['uz'],
        description_en=copy['desc']['en'],
        link=_http_link(link or copy.get('link') or ''),
        template_key=key,
        due_date=None,
        date_confirmed=False,
    )


def _uni_templates(uni: University) -> list[tuple[str, dict]]:
    name = _tri(uni.name_ru, uni.name_uz, uni.name_en)
    admission = _tri(uni.admission_ru, uni.admission_uz, uni.admission_en)
    subjects = _tri(uni.subjects_ru, uni.subjects_uz, uni.subjects_en)
    grants = _tri(uni.scholarships_ru, uni.scholarships_uz, uni.scholarships_en)
    items = [(
        f'uni-{uni.id}-requirements',
        {
            'category': 'research',
            'priority': 'high',
            'title': _tri(
                f'Прочитать условия поступления: {name["ru"]}',
                f"Qabul shartlarini o'qish: {name['uz']}",
                f'Read the admission requirements: {name["en"]}',
            ),
            'desc': _tri(
                admission['ru'] or 'В каталоге UniSearch условия поступления для этого вуза не заполнены. Проверьте официальный сайт и отметьте задачу, когда сверите требования.',
                admission['uz'] or "UniSearch katalogida bu OTM uchun qabul shartlari to'ldirilmagan. Rasmiy saytni tekshiring.",
                admission['en'] or 'UniSearch does not list admission requirements for this university. Check the official site, then complete the task.',
            ),
        },
    )]
    if _filled(uni.subjects_ru, uni.subjects_uz, uni.subjects_en):
        items.append((
            f'uni-{uni.id}-subjects',
            {
                'category': 'exam',
                'priority': 'medium',
                'title': _tri(
                    f'Записать вступительные предметы: {name["ru"]}',
                    f"Kirish fanlarini yozib olish: {name['uz']}",
                    f'Note the entrance subjects: {name["en"]}',
                ),
                'desc': _tri(
                    f'Текст из каталога, не отдельная подтверждённая дата: {subjects["ru"]}',
                    f"Katalog matni, alohida tasdiqlangan sana emas: {subjects['uz']}",
                    f'Catalog text, not a separately confirmed date: {subjects["en"]}',
                ),
            },
        ))
    if _filled(uni.scholarships_ru, uni.scholarships_uz, uni.scholarships_en):
        items.append((
            f'uni-{uni.id}-grants',
            {
                'category': 'scholarship',
                'priority': 'medium',
                'title': _tri(
                    f'Проверить информацию о грантах: {name["ru"]}',
                    f"Grant ma'lumotini tekshirish: {name['uz']}",
                    f'Check the grant information: {name["en"]}',
                ),
                'desc': _tri(
                    f'Текст из каталога. Срок в этой задаче не назначен: {grants["ru"]}',
                    f"Katalog matni. Bu vazifada muddat qo'yilmagan: {grants['uz']}",
                    f'Catalog text. This task has no deadline: {grants["en"]}',
                ),
            },
        ))
    return items


def generate_roadmap(user, grade: str, major: str, year, university_ids: list[int]):
    plan, _ = AdmissionPlan.objects.get_or_create(user=user)
    plan.grade = grade or ''
    plan.major = (major or '').strip()[:160]
    plan.admission_year = year
    plan.onboarded = True
    plan.wizard_step = 5
    plan.save()

    ids = list(dict.fromkeys(university_ids))[:MAX_UNIS]
    known = {u.id: u for u in University.objects.filter(id__in=ids)}
    missing = [i for i in ids if i not in known]
    if missing:
        raise serializers.ValidationError({'universityIds': 'unknown'})  # caught by the view
    existing = TrackUniversity.objects.filter(user=user).count()
    for uni_id in ids:
        if TrackUniversity.objects.filter(user=user, university_id=uni_id).exists():
            continue
        if existing >= MAX_UNIS:
            break
        TrackUniversity.objects.create(user=user, university=known[uni_id])
        existing += 1

    if TrackTask.objects.filter(user=user).count() < MAX_TASKS:
        for key, copy in CORE_COPY.items():
            _ensure_task(user, key, None, copy)
    for row in TrackUniversity.objects.filter(user=user).select_related('university'):
        for key, copy in _uni_templates(row.university):
            if TrackTask.objects.filter(user=user).count() >= MAX_TASKS:
                break
            _ensure_task(user, key, row.university, copy, row.university.website)


class UniTrackView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not TrackTask.objects.filter(user=request.user).exists():
            plan = AdmissionPlan.objects.filter(user=request.user).first()
            chosen = list(TrackUniversity.objects.filter(user=request.user).values_list('university_id', flat=True))
            if not chosen:
                chosen = list(University.objects.order_by('id').values_list('id', flat=True)[:3])
            generate_roadmap(
                request.user,
                plan.grade if plan else '',
                plan.major if plan else '',
                plan.admission_year if plan else None,
                chosen,
            )
        return Response(_snapshot(request.user))


class UniTrackPlanView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request):
        ser = PlanPatchSerializer(data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        plan, _ = AdmissionPlan.objects.get_or_create(user=request.user)
        data = ser.validated_data
        if 'grade' in data:
            plan.grade = data['grade']
        if 'major' in data:
            plan.major = data['major'].strip()
        if 'admissionYear' in data:
            plan.admission_year = data['admissionYear']
        if 'wizardStep' in data:
            plan.wizard_step = data['wizardStep']
        plan.save()
        return Response(_snapshot(request.user))


class UniTrackGenerateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        ser = GenerateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        try:
            generate_roadmap(
                request.user,
                data.get('grade') or '',
                data.get('major') or '',
                data.get('admissionYear'),
                data.get('universityIds') or [],
            )
        except serializers.ValidationError as exc:
            return Response(exc.detail, status=400)
        return Response(_snapshot(request.user), status=status.HTTP_200_OK)


class UniTrackUniversityView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            uni_id = int(request.data.get('universityId'))
        except (TypeError, ValueError):
            return Response({'detail': 'universityId'}, status=400)
        uni = University.objects.filter(pk=uni_id).first()
        if uni is None:
            return Response({'detail': 'unknown university'}, status=400)
        if TrackUniversity.objects.filter(user=request.user).count() >= MAX_UNIS and not TrackUniversity.objects.filter(user=request.user, university=uni).exists():
            return Response({'detail': 'limit'}, status=400)
        TrackUniversity.objects.get_or_create(user=request.user, university=uni)
        return Response(_snapshot(request.user), status=status.HTTP_201_CREATED)

    def delete(self, request, university_id: int):
        TrackUniversity.objects.filter(user=request.user, university_id=university_id).delete()
        return Response(_snapshot(request.user))


class UniTrackTaskListView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if TrackTask.objects.filter(user=request.user).count() >= MAX_TASKS:
            return Response({'detail': 'limit'}, status=400)
        ser = TaskWriteSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        try:
            uni = _owned_university(request.user, data.get('universityId'))
        except serializers.ValidationError as exc:
            return Response(exc.detail, status=400)
        try:
            due, confirmed = _clean_date(data.get('dueDate'), True)
        except serializers.ValidationError:
            return Response({'detail': 'date'}, status=400)
        title = data['title'].strip()
        description = (data.get('description') or '').strip()
        task = TrackTask.objects.create(
            user=request.user,
            university=uni,
            category=data['category'],
            priority=data['priority'],
            status=data['status'],
            title_ru=title,
            title_uz=title,
            title_en=title,
            description_ru=description,
            description_uz=description,
            description_en=description,
            due_date=due,
            date_confirmed=confirmed,
            link=_http_link(data.get('link') or ''),
        )
        return Response(_task_payload(task), status=status.HTTP_201_CREATED)


class UniTrackTaskDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, task_id: int):
        task = get_object_or_404(TrackTask, pk=task_id, user=request.user)
        ser = TaskPatchSerializer(data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        if 'title' in data:
            title = data['title'].strip()
            task.title_ru = task.title_uz = task.title_en = title
        if 'description' in data:
            description = data['description'].strip()
            task.description_ru = task.description_uz = task.description_en = description
        if 'category' in data:
            task.category = data['category']
        if 'priority' in data:
            task.priority = data['priority']
        if 'status' in data:
            task.status = data['status']
        if 'universityId' in data:
            try:
                task.university = _owned_university(request.user, data['universityId'])
            except serializers.ValidationError as exc:
                return Response(exc.detail, status=400)
        if 'dueDate' in data:
            try:
                task.due_date, task.date_confirmed = _clean_date(data['dueDate'], True)
            except serializers.ValidationError:
                return Response({'detail': 'date'}, status=400)
        if 'link' in data:
            task.link = _http_link(data['link'])
        task.save()
        return Response(_task_payload(task))

    def delete(self, request, task_id: int):
        task = get_object_or_404(TrackTask, pk=task_id, user=request.user)
        task.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class UniTrackEventListView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if TrackEvent.objects.filter(user=request.user).count() >= MAX_EVENTS:
            return Response({'detail': 'limit'}, status=400)
        ser = EventWriteSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        try:
            uni = _owned_university(request.user, data.get('universityId'))
        except serializers.ValidationError as exc:
            return Response(exc.detail, status=400)
        try:
            when, confirmed = _clean_date(data.get('eventDate'), True)
        except serializers.ValidationError:
            return Response({'detail': 'date'}, status=400)
        event = TrackEvent.objects.create(
            user=request.user,
            university=uni,
            title=data['title'].strip(),
            note=(data.get('note') or '').strip(),
            kind=data['kind'],
            event_date=when,
            date_confirmed=confirmed,
            link=_http_link(data.get('link') or ''),
        )
        return Response(_event_payload(event), status=status.HTTP_201_CREATED)


class UniTrackEventDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, event_id: int):
        event = get_object_or_404(TrackEvent, pk=event_id, user=request.user)
        ser = EventWriteSerializer(data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        if 'title' in data:
            event.title = data['title'].strip()
        if 'note' in data:
            event.note = data['note'].strip()
        if 'kind' in data:
            event.kind = data['kind']
        if 'universityId' in data:
            try:
                event.university = _owned_university(request.user, data['universityId'])
            except serializers.ValidationError as exc:
                return Response(exc.detail, status=400)
        if 'eventDate' in data:
            try:
                event.event_date, event.date_confirmed = _clean_date(data['eventDate'], True)
            except serializers.ValidationError:
                return Response({'detail': 'date'}, status=400)
        if 'link' in data:
            event.link = _http_link(data['link'])
        event.save()
        return Response(_event_payload(event))

    def delete(self, request, event_id: int):
        event = get_object_or_404(TrackEvent, pk=event_id, user=request.user)
        event.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
