from django.urls import path

from .unitrack import (
    UniTrackEventDetailView,
    UniTrackEventListView,
    UniTrackGenerateView,
    UniTrackPlanView,
    UniTrackTaskDetailView,
    UniTrackTaskListView,
    UniTrackUniversityView,
    UniTrackView,
)
from .views import ChecklistMeView, ChecklistTemplateView, MergeLocalView, SavedListView

urlpatterns = [
    path('me/merge-local/', MergeLocalView.as_view(), name='me-merge-local'),
    path('me/saved/', SavedListView.as_view(), name='me-saved'),
    path('me/checklist/', ChecklistMeView.as_view(), name='me-checklist'),
    path('checklist/template/', ChecklistTemplateView.as_view(), name='checklist-template'),
    path('me/unitrack/', UniTrackView.as_view(), name='me-unitrack'),
    path('me/unitrack/plan/', UniTrackPlanView.as_view(), name='me-unitrack-plan'),
    path('me/unitrack/generate/', UniTrackGenerateView.as_view(), name='me-unitrack-generate'),
    path('me/unitrack/universities/', UniTrackUniversityView.as_view(), name='me-unitrack-universities'),
    path('me/unitrack/universities/<int:university_id>/', UniTrackUniversityView.as_view(), name='me-unitrack-university'),
    path('me/unitrack/tasks/', UniTrackTaskListView.as_view(), name='me-unitrack-tasks'),
    path('me/unitrack/tasks/<int:task_id>/', UniTrackTaskDetailView.as_view(), name='me-unitrack-task'),
    path('me/unitrack/events/', UniTrackEventListView.as_view(), name='me-unitrack-events'),
    path('me/unitrack/events/<int:event_id>/', UniTrackEventDetailView.as_view(), name='me-unitrack-event'),
]
