from rest_framework import serializers, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.catalog.models import University

from .checklist import CHECKLIST_TEMPLATE, TEMPLATE_IDS
from .models import SavedUniversity, UserChecklist


class MergeLocalSerializer(serializers.Serializer):
    savedIds = serializers.ListField(
        child=serializers.IntegerField(min_value=1),
        required=False,
        default=list,
    )
    checklist = serializers.DictField(required=False, default=dict)


class MergeLocalView(APIView):
    """
    One-shot sync of anonymous localStorage progress after login/register.
    Merges saved universities and checklist without wiping server data.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request):
        ser = MergeLocalSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = request.user
        saved_ids = list(dict.fromkeys(ser.validated_data.get('savedIds') or []))
        checklist_in = ser.validated_data.get('checklist') or {}

        known = set(
            University.objects.filter(id__in=saved_ids).values_list('id', flat=True)
        )
        created_saved = 0
        for uni_id in saved_ids:
            if uni_id not in known:
                continue
            _, was_created = SavedUniversity.objects.get_or_create(
                user=user,
                university_id=uni_id,
            )
            if was_created:
                created_saved += 1

        row, _ = UserChecklist.objects.get_or_create(user=user)
        merged_items = dict(row.items or {})
        for key, val in checklist_in.items():
            if key in TEMPLATE_IDS and val:
                merged_items[key] = True
        row.items = merged_items
        row.save(update_fields=['items', 'updated_at'])

        saved_now = list(
            SavedUniversity.objects.filter(user=user)
            .order_by('-created_at')
            .values_list('university_id', flat=True)
        )
        return Response(
            {
                'ok': True,
                'mergedSaved': created_saved,
                'savedIds': saved_now,
                'checklist': merged_items,
            },
            status=status.HTTP_200_OK,
        )


class SavedListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        ids = list(
            SavedUniversity.objects.filter(user=request.user)
            .order_by('-created_at')
            .values_list('university_id', flat=True)
        )
        return Response({'savedIds': ids})

    def put(self, request):
        raw = request.data.get('savedIds')
        if not isinstance(raw, list):
            return Response({'detail': 'savedIds must be a list'}, status=400)
        ids = []
        for x in raw:
            try:
                ids.append(int(x))
            except (TypeError, ValueError):
                continue
        ids = list(dict.fromkeys(ids))
        known = set(University.objects.filter(id__in=ids).values_list('id', flat=True))
        SavedUniversity.objects.filter(user=request.user).exclude(university_id__in=known).delete()
        for uni_id in ids:
            if uni_id in known:
                SavedUniversity.objects.get_or_create(user=request.user, university_id=uni_id)
        return Response({'savedIds': ids})


class ChecklistTemplateView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response(CHECKLIST_TEMPLATE)


class ChecklistMeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        row, _ = UserChecklist.objects.get_or_create(user=request.user)
        return Response({'checklist': row.items or {}})

    def put(self, request):
        raw = request.data.get('checklist')
        if not isinstance(raw, dict):
            return Response({'detail': 'checklist must be an object'}, status=400)
        cleaned = {}
        for key, val in raw.items():
            if key in TEMPLATE_IDS:
                cleaned[str(key)] = bool(val)
        row, _ = UserChecklist.objects.get_or_create(user=request.user)
        row.items = cleaned
        row.save(update_fields=['items', 'updated_at'])
        return Response({'checklist': cleaned})
