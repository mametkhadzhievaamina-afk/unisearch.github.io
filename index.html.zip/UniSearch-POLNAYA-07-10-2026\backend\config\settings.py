"""
UniSearch API settings.

Postgres is the production/default database.
Set DJANGO_USE_SQLITE=1 for local bootstrap when Postgres is unavailable.
"""

from datetime import timedelta
from pathlib import Path
import os

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / '.env')


def env(key: str, default: str | None = None) -> str | None:
    return os.environ.get(key, default)


def env_bool(key: str, default: bool = False) -> bool:
    raw = os.environ.get(key)
    if raw is None:
        return default
    return raw.strip().lower() in {'1', 'true', 'yes', 'on'}


_INSECURE_SECRETS = {
    '',
    'change-me',
    'change-me-in-production',
    'django-insecure-dev-only-change-me',
    'dev-local-unisearch',
    'dev-unisearch-skeleton-key-not-for-production',
}

SECRET_KEY = env('DJANGO_SECRET_KEY', 'django-insecure-dev-only-change-me') or ''
# Local SQLite desktop package defaults to DEBUG when DJANGO_DEBUG is unset.
_USE_SQLITE = env_bool('DJANGO_USE_SQLITE', False)
DEBUG = env_bool('DJANGO_DEBUG', _USE_SQLITE)

if not DEBUG and SECRET_KEY.strip() in _INSECURE_SECRETS:
    raise RuntimeError('DJANGO_SECRET_KEY must be set to a unique value when DJANGO_DEBUG is off.')

def _csv(key: str, default: str = '') -> list[str]:
    raw = env(key, default if DEBUG else '') or ''
    return [part.strip() for part in raw.split(',') if part.strip()]

_LOCAL_HOSTS = 'localhost,127.0.0.1'
_LOCAL_ORIGINS = (
    'http://127.0.0.1:5173,http://localhost:5173,'
    'http://127.0.0.1:5176,http://localhost:5176,'
    'http://127.0.0.1:4173,http://localhost:4173'
)

ALLOWED_HOSTS = _csv('DJANGO_ALLOWED_HOSTS', _LOCAL_HOSTS if DEBUG else '')
CORS_ALLOWED_ORIGINS = _csv('CORS_ALLOWED_ORIGINS', _LOCAL_ORIGINS if DEBUG else '')
CSRF_TRUSTED_ORIGINS = _csv('CSRF_TRUSTED_ORIGINS', _LOCAL_ORIGINS if DEBUG else '')
CORS_ALLOW_CREDENTIALS = True

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',
    'rest_framework',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'apps.common',
    'apps.catalog',
    'apps.accounts',
    'apps.progress',
    'apps.community',
]

AUTH_USER_MODEL = 'accounts.User'

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

# Database: Postgres by default; SQLite only when DJANGO_USE_SQLITE=1
USE_SQLITE = env_bool('DJANGO_USE_SQLITE', False)

if USE_SQLITE:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': env('POSTGRES_DB', 'unisearch'),
            'USER': env('POSTGRES_USER', 'unisearch'),
            'PASSWORD': env('POSTGRES_PASSWORD', 'unisearch'),
            'HOST': env('POSTGRES_HOST', '127.0.0.1'),
            'PORT': env('POSTGRES_PORT', '5432'),
            'CONN_MAX_AGE': 60,
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 8},
    },
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Tashkent'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# One reverse proxy (nginx). DRF uses this so throttles see the client, not the proxy.
NUM_PROXIES = int(env('NUM_PROXIES', '1') or '1')

SITE_URL = (env('SITE_URL', 'http://127.0.0.1:5176') or 'http://127.0.0.1:5176').rstrip('/')
ADMIN_URL_PATH = (env('DJANGO_ADMIN_PATH', 'admin') or 'admin').strip('/')

EMAIL_BACKEND = env('EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend')
EMAIL_HOST = env('EMAIL_HOST', '')
EMAIL_PORT = int(env('EMAIL_PORT', '587') or '587')
EMAIL_HOST_USER = env('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = env('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = env_bool('EMAIL_USE_TLS', True)
DEFAULT_FROM_EMAIL = env('DEFAULT_FROM_EMAIL', 'UniSearch <noreply@localhost>')

SMS_PROVIDER = env('SMS_PROVIDER', 'log')
ESKIZ_EMAIL = env('ESKIZ_EMAIL', '')
ESKIZ_PASSWORD = env('ESKIZ_PASSWORD', '')
ESKIZ_FROM = env('ESKIZ_FROM', '4546')

TURNSTILE_SECRET = env('TURNSTILE_SECRET', '')

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unisearch',
    }
}
if (env('DJANGO_CACHE', '') or '').strip().lower() == 'db':
    CACHES = {
        'default': {
            'BACKEND': 'django.core.cache.backends.db.DatabaseCache',
            'LOCATION': 'unisearch_cache',
        }
    }

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.AllowAny',
    ),
    'DEFAULT_PAGINATION_CLASS': 'apps.common.pagination.FlexiblePagination',
    'PAGE_SIZE': 20,
    'DEFAULT_THROTTLE_CLASSES': (
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ),
    'DEFAULT_THROTTLE_RATES': {
        'anon': '200/hour',
        'user': '1000/hour',
        'login': '10/min',
        'register': '5/min',
        'refresh': '30/min',
        'verify_send': '5/hour',
    },
    'NUM_PROXIES': NUM_PROXIES,
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=int(env('JWT_ACCESS_MINUTES', '60') or '60')),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=int(env('JWT_REFRESH_DAYS', '7') or '7')),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'AUTH_HEADER_TYPES': ('Bearer',),
}

if not DEBUG:
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
    SECURE_SSL_REDIRECT = env_bool('DJANGO_SECURE_SSL_REDIRECT', True)
    SECURE_HSTS_SECONDS = int(env('DJANGO_HSTS_SECONDS', '31536000') or '31536000')
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_REFERRER_POLICY = 'same-origin'
    X_FRAME_OPTIONS = 'DENY'
    USE_X_FORWARDED_HOST = True

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {'class': 'logging.StreamHandler'},
    },
    'root': {'handlers': ['console'], 'level': 'INFO'},
    'loggers': {
        'django.request': {'handlers': ['console'], 'level': 'WARNING', 'propagate': False},
        'apps.accounts.sms': {'handlers': ['console'], 'level': 'INFO', 'propagate': False},
    },
}
