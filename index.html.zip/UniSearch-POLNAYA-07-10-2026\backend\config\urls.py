from django.contrib import admin
from django.urls import include, path

from django.conf import settings

urlpatterns = [
    path(f'{settings.ADMIN_URL_PATH}/', admin.site.urls),
    path('api/v1/', include('apps.common.urls')),
    path('api/v1/', include('apps.catalog.urls')),
    path('api/v1/', include('apps.accounts.urls')),
    path('api/v1/', include('apps.progress.urls')),
    path('api/v1/', include('apps.community.urls')),
    path('', include('apps.catalog.seo_urls')),
]
