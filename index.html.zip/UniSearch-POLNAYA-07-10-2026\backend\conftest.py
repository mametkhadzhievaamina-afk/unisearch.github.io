import os

os.environ['DJANGO_DEBUG'] = '1'
os.environ['DJANGO_USE_SQLITE'] = '1'
os.environ['DJANGO_SECRET_KEY'] = 'test-secret-key-not-production-value'
os.environ['DJANGO_ALLOWED_HOSTS'] = 'localhost,127.0.0.1,testserver'

import pytest
from django.core.cache import cache


@pytest.fixture(autouse=True)
def _clear_cache():
    cache.clear()
    yield
    cache.clear()
