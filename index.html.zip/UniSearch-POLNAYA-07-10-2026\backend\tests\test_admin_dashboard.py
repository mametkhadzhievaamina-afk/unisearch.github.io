import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.catalog.models import Scholarship, University

pytestmark = pytest.mark.django_db


def _staff(email='staff@example.com'):
    return User.objects.create_user(email.split('@')[0], email=email, password='longpassword1', is_staff=True)


def _login(api, user):
    res = api.post('/api/v1/auth/login/', {'login': user.email, 'password': 'longpassword1'}, format='json')
    api.credentials(HTTP_AUTHORIZATION=f"Bearer {res.data['access']}")


def test_admin_routes_reject_anonymous_and_regular_users():
    api = APIClient()
    assert api.get('/api/v1/admin/overview/').status_code in (401, 403)
    assert api.post('/api/v1/admin/universities/', {'nameRu': 'X', 'city': 'Y'}, format='json').status_code in (401, 403)
    user = User.objects.create_user('plain', email='plain@example.com', password='longpassword1')
    _login(api, user)
    for path in ('/api/v1/admin/overview/', '/api/v1/admin/universities/', '/api/v1/admin/users/', '/api/v1/admin/scholarships/'):
        assert api.get(path).status_code == 403
    assert api.patch('/api/v1/admin/users/1/', {'isStaff': True}, format='json').status_code == 403


def test_staff_university_crud_and_validation():
    api = APIClient()
    _login(api, _staff())
    created = api.post(
        '/api/v1/admin/universities/',
        {'nameRu': 'Новый вуз', 'city': 'Samarkand', 'costUsd': 1200, 'website': 'https://example.edu', 'rating': '4'},
        format='json',
    )
    assert created.status_code == 201
    uni_id = created.data['id']
    assert created.data['nameRu'] == 'Новый вуз'
    assert created.data['programCount'] == 0
    assert 'password' not in created.data
    again = api.post('/api/v1/admin/universities/', {'nameRu': 'новый вуз', 'city': 'samarkand'}, format='json')
    assert again.status_code == 400
    bad = api.post('/api/v1/admin/universities/', {'nameRu': 'Другой', 'city': 'Bukhara', 'website': 'ftp://nope'}, format='json')
    assert bad.status_code == 400
    patched = api.patch(f'/api/v1/admin/universities/{uni_id}/', {'city': 'Bukhara'}, format='json')
    assert patched.status_code == 200
    assert patched.data['city'] == 'Bukhara'
    assert api.delete(f'/api/v1/admin/universities/{uni_id}/').status_code == 204
    assert not University.objects.filter(pk=uni_id).exists()


def test_staff_cannot_change_self_or_passwords_and_can_toggle_another_user():
    api = APIClient()
    staff = _staff()
    other = User.objects.create_user('other', email='other@example.com', password='longpassword1')
    _login(api, staff)
    people = api.get('/api/v1/admin/users/')
    assert people.status_code == 200
    assert 'password' not in people.data[0]
    assert 'joinedAt' in people.data[0]
    self_change = api.patch(f'/api/v1/admin/users/{staff.id}/', {'is_active': False, 'isStaff': False}, format='json')
    assert self_change.status_code == 400
    staff.refresh_from_db()
    assert staff.is_staff is True
    assert staff.is_active is True
    secret = api.patch(f'/api/v1/admin/users/{other.id}/', {'password': 'stolen', 'isStaff': True}, format='json')
    assert secret.status_code == 400
    other.refresh_from_db()
    assert other.is_staff is False
    toggled = api.patch(f'/api/v1/admin/users/{other.id}/', {'isStaff': True, 'is_active': False}, format='json')
    assert toggled.status_code == 200
    assert toggled.data['isStaff'] is True
    assert toggled.data['is_active'] is False
    assert 'password' not in toggled.data


def test_overview_uses_real_counts_and_scholarship_text_can_be_edited():
    api = APIClient()
    _login(api, _staff('lead@example.com'))
    Scholarship.objects.create(id='grant-1', title='Grant', country='UZ', amount='100', deadline='catalog text', eligibility='students', to='/tools')
    overview = api.get('/api/v1/admin/overview/')
    assert overview.status_code == 200
    assert overview.data['published'] is None
    assert overview.data['scholarships'] == 1
    assert overview.data['users'] >= 1
    assert isinstance(overview.data['recentUsers'], list)
    saved = api.patch('/api/v1/admin/scholarships/grant-1/', {'deadline': 'still a note', 'title': 'Grant updated'}, format='json')
    assert saved.status_code == 200
    assert saved.data['deadline'] == 'still a note'
    assert saved.data['title'] == 'Grant updated'
