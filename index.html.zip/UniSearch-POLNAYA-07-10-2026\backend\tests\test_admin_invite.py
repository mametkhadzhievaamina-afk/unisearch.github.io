import pytest
from django.core.management import call_command
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient

from apps.accounts.invites import create_invite
from apps.accounts.models import AdminInvite, User

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


def test_open_admin_url_does_not_grant_staff(api):
    res = api.post(
        '/api/v1/auth/admin-register/',
        {'email': 'new-admin@example.com', 'password': 'longpassword1', 'name': 'Ada', 'invite': 'not-a-real-invite'},
        format='json',
    )
    assert res.status_code == 400
    assert not User.objects.filter(email='new-admin@example.com').exists()


def test_invite_registers_staff_once(api):
    raw, _invite = create_invite(None)
    body = {'email': 'ada@example.com', 'password': 'longpassword1', 'name': 'Ada', 'invite': raw}
    ok = api.post('/api/v1/auth/admin-register/', body, format='json')
    assert ok.status_code == 201
    user = User.objects.get(email='ada@example.com')
    assert user.is_staff is True
    assert user.is_superuser is False
    assert ok.data['user']['isStaff'] is True
    again = api.post(
        '/api/v1/auth/admin-register/',
        {'email': 'ada2@example.com', 'password': 'longpassword1', 'name': 'Ada2', 'invite': raw},
        format='json',
    )
    assert again.status_code == 400
    assert not User.objects.filter(email='ada2@example.com').exists()


def test_regular_register_cannot_set_staff(api):
    res = api.post(
        '/api/v1/auth/register/',
        {'email': 'user@example.com', 'password': 'longpassword1', 'isStaff': True, 'is_staff': True, 'role': 'admin'},
        format='json',
    )
    assert res.status_code == 400
    assert not User.objects.filter(email='user@example.com').exists()


def test_me_cannot_promote_self(api):
    user = User.objects.create_user(username='u@example.com', email='u@example.com', password='longpassword1')
    api.force_authenticate(user=user)
    res = api.patch('/api/v1/auth/me/', {'name': 'U', 'isStaff': True, 'is_staff': True}, format='json')
    assert res.status_code == 400
    user.refresh_from_db()
    assert user.is_staff is False
    assert user.name != 'U' or res.status_code == 400


def test_staff_endpoint_rejects_regular_user(api):
    user = User.objects.create_user(username='plain@example.com', email='plain@example.com', password='longpassword1')
    api.force_authenticate(user=user)
    assert api.get('/api/v1/admin/overview/').status_code == 403
    assert api.post('/api/v1/admin/invites/', {}, format='json').status_code == 403


def test_staff_can_issue_invite(api):
    staff = User.objects.create_user(
        username='staff@example.com', email='staff@example.com', password='longpassword1', is_staff=True,
    )
    api.force_authenticate(user=staff)
    res = api.post('/api/v1/admin/invites/', {}, format='json')
    assert res.status_code == 201
    assert res.data['path'].startswith('/admin/register?invite=')
    assert AdminInvite.objects.filter(created_by=staff, used_at__isnull=True).count() == 1


def test_expired_invite_is_rejected(api):
    raw, invite = create_invite(None)
    invite.expires_at = timezone.now() - timedelta(minutes=1)
    invite.save(update_fields=['expires_at'])
    res = api.post(
        '/api/v1/auth/admin-register/',
        {'email': 'late@example.com', 'password': 'longpassword1', 'invite': raw},
        format='json',
    )
    assert res.status_code == 400
    assert not User.objects.filter(email='late@example.com').exists()


def test_create_admin_command():
    call_command('create_admin', email='root@example.com', password='longpassword1', name='Root')
    user = User.objects.get(email='root@example.com')
    assert user.is_staff and user.is_superuser
    assert user.check_password('longpassword1')
