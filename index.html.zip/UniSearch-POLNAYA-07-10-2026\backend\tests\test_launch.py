import pytest
from django.core.management import call_command
from rest_framework.test import APIClient

from apps.accounts.models import User, VerificationCode
from apps.accounts.verification import hash_code
from apps.community.models import Comment
pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


def test_register_login_refresh_logout(api):
    reg = api.post('/api/v1/auth/register/', {'email': 'a@example.com', 'password': 'longpassword1', 'name': 'A'}, format='json')
    assert reg.status_code == 201
    assert 'access' in reg.data
    bad = api.post('/api/v1/auth/login/', {'login': 'missing@example.com', 'password': 'longpassword1'}, format='json')
    wrong = api.post('/api/v1/auth/login/', {'login': 'a@example.com', 'password': 'longpassword9'}, format='json')
    assert bad.status_code == 400 and wrong.status_code == 400
    assert bad.data == wrong.data
    ok = api.post('/api/v1/auth/login/', {'login': 'a@example.com', 'password': 'longpassword1'}, format='json')
    assert ok.status_code == 200
    refreshed = api.post('/api/v1/auth/refresh/', {'refresh': ok.data['refresh']}, format='json')
    assert refreshed.status_code == 200
    api.credentials(HTTP_AUTHORIZATION=f"Bearer {ok.data['access']}")
    out = api.post('/api/v1/auth/logout/', {'refresh': refreshed.data.get('refresh') or ok.data['refresh']}, format='json')
    assert out.status_code == 200


def test_uz_phone_register(api):
    res = api.post('/api/v1/auth/register/', {'phone': '901234567', 'password': 'longpassword1'}, format='json')
    assert res.status_code == 201
    assert User.objects.get(phone='+998901234567')


def test_login_lockout(api):
    api.post('/api/v1/auth/register/', {'email': 'lock@example.com', 'password': 'longpassword1'}, format='json')
    status = 0
    for _ in range(6):
        status = api.post('/api/v1/auth/login/', {'login': 'lock@example.com', 'password': 'nope-nope'}, format='json').status_code
    assert status == 429


def test_catalog_filter(api):
    call_command('seed_catalog')
    res = api.get('/api/v1/universities/', {'city': 'Ташкент', 'page': 1})
    assert res.status_code == 200
    assert res.data['count'] >= 1


def test_comment_moderation_and_report(api):
    created = api.post('/api/v1/comments/', {'name': 'Ann', 'text': 'hello world'}, format='json')
    assert created.status_code == 201
    assert api.get('/api/v1/comments/').data == []
    Comment.objects.filter(pk=created.data['id']).update(is_approved=True)
    listed = api.get('/api/v1/comments/').data
    assert listed[0]['text'] == 'hello world'
    api.post(f"/api/v1/comments/{created.data['id']}/report/")
    api.post(f"/api/v1/comments/{created.data['id']}/report/")
    api.post(f"/api/v1/comments/{created.data['id']}/report/")
    assert api.get('/api/v1/comments/').data == []


def test_phone_verify(api):
    api.post('/api/v1/auth/register/', {'phone': '+998901111111', 'password': 'longpassword1'}, format='json')
    sent = api.post('/api/v1/auth/verify/request/', {'channel': 'phone', 'target': '+998901111111'}, format='json')
    assert sent.status_code == 200
    row = VerificationCode.objects.filter(target='+998901111111').latest('created_at')
    row.code_hash = hash_code('123456')
    row.attempts = 0
    row.save()
    ok = api.post('/api/v1/auth/verify/confirm/', {'channel': 'phone', 'target': '+998901111111', 'code': '123456'}, format='json')
    assert ok.status_code == 200
    assert User.objects.get(phone='+998901111111').is_phone_verified is True
