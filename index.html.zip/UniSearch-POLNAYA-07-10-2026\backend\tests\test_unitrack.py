import pytest
from datetime import date, timedelta
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.catalog.models import Scholarship, University
from apps.progress.models import TrackTask

pytestmark = pytest.mark.django_db


def _user(email):
    return User.objects.create_user(email.split('@')[0], email=email, password='longpassword1')


def _auth(api, user):
    res = api.post('/api/v1/auth/login/', {'login': user.email, 'password': 'longpassword1'}, format='json')
    api.credentials(HTTP_AUTHORIZATION=f"Bearer {res.data['access']}")


def _uni(**extra):
    defaults = dict(
        id=9001,
        name_ru='Тест вуз',
        name_uz='Test OTM',
        name_en='Test University',
        city='Tashkent',
        cost_ru='',
        cost_uz='',
        cost_en='',
        rating='0',
        subjects_ru='математика',
        subjects_uz='matematika',
        subjects_en='math',
        exams_date_ru='текст каталога, не дата',
        admission_ru='аттестат',
        scholarships_ru='есть заметка о гранте',
        website='https://example.edu',
    )
    defaults.update(extra)
    return University.objects.create(**defaults)


def test_unitrack_requires_login():
    api = APIClient()
    assert api.get('/api/v1/me/unitrack/').status_code == 401


def test_unitrack_plan_tasks_and_isolation():
    owner = _user('owner@example.com')
    other = _user('other@example.com')
    uni = _uni()
    Scholarship.objects.create(
        id='test-grant',
        title='Test grant',
        country='Uzbekistan',
        amount='note',
        deadline='15 Jun',
        eligibility='catalog text',
        to='/university/9001',
    )
    api = APIClient()
    _auth(api, owner)
    generated = api.post('/api/v1/me/unitrack/generate/', {
        'grade': '11',
        'major': 'Software',
        'admissionYear': 2027,
        'universityIds': [uni.id],
    }, format='json')
    assert generated.status_code == 200
    board = generated.data
    assert board['plan']['onboarded'] is True
    assert board['plan']['stage'] == 'research'
    assert board['universities'][0]['website'] == 'https://example.edu'
    assert board['universities'][0]['costRu'] == ''
    assert all(task['dueDate'] is None and task['dateConfirmed'] is False for task in board['tasks'])
    assert any(note['confirmed'] is False and note['kind'] == 'exam' for note in board['catalogNotes'])
    assert any(note['kind'] == 'scholarship' for note in board['catalogNotes'])
    codes = {item['code'] for item in board['recommendations']}
    assert 'check_requirements' in codes
    assert 'check_grants' in codes
    assert 'add_exam_schedule' in codes

    created = api.post('/api/v1/me/unitrack/tasks/', {
        'title': 'My task',
        'description': 'Read the site',
        'category': 'documents',
        'priority': 'high',
        'universityId': uni.id,
        'dueDate': (date.today() + timedelta(days=2)).isoformat(),
        'link': 'https://example.edu/apply',
    }, format='json')
    assert created.status_code == 201
    task_id = created.data['id']
    assert created.data['dateConfirmed'] is True
    done = api.patch(f'/api/v1/me/unitrack/tasks/{task_id}/', {'status': 'completed'}, format='json')
    assert done.status_code == 200 and done.data['status'] == 'completed'
    edited = api.patch(f'/api/v1/me/unitrack/tasks/{task_id}/', {'title': 'Updated'}, format='json')
    assert edited.data['titleEn'] == 'Updated'

    event = api.post('/api/v1/me/unitrack/events/', {
        'title': 'Study block',
        'kind': 'study',
        'eventDate': date.today().isoformat(),
    }, format='json')
    assert event.status_code == 201
    event_id = event.data['id']
    renamed = api.patch(f'/api/v1/me/unitrack/events/{event_id}/', {'title': 'Evening study'}, format='json')
    assert renamed.status_code == 200

    stranger = APIClient()
    _auth(stranger, other)
    assert stranger.patch(f'/api/v1/me/unitrack/tasks/{task_id}/', {'title': 'nope'}, format='json').status_code == 404
    stranger_board = stranger.get('/api/v1/me/unitrack/').data
    assert stranger_board['tasks']
    assert all(item['templateKey'].startswith(('core-', 'uni-')) for item in stranger_board['tasks'])
    assert all(item['titleEn'] != 'Updated' for item in stranger_board['tasks'])
    assert stranger.delete(f'/api/v1/me/unitrack/events/{event_id}/').status_code == 404

    assert api.delete(f'/api/v1/me/unitrack/tasks/{task_id}/').status_code == 204
    assert api.delete(f'/api/v1/me/unitrack/events/{event_id}/').status_code == 204
    assert TrackTask.objects.filter(user=owner, title_en='Updated').count() == 0
    again = api.get('/api/v1/me/unitrack/')
    assert again.status_code == 200
    assert any(task['templateKey'] == 'core-exam' for task in again.data['tasks'])


def test_unknown_university_rejected():
    user = _user('plain@example.com')
    api = APIClient()
    _auth(api, user)
    res = api.post('/api/v1/me/unitrack/universities/', {'universityId': 999999}, format='json')
    assert res.status_code == 400
