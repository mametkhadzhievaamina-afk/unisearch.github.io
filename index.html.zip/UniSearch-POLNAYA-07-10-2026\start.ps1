$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# Force local env BEFORE any Django import (dotenv does not override existing process vars).
$env:DJANGO_SECRET_KEY = "unisearch-local-desktop-key-2026"
$env:DJANGO_DEBUG = "1"
$env:DJANGO_ALLOWED_HOSTS = "localhost,127.0.0.1"
$env:DJANGO_ADMIN_PATH = "admin"
$env:DJANGO_USE_SQLITE = "1"
$env:CORS_ALLOWED_ORIGINS = "http://127.0.0.1:4173,http://localhost:4173,http://127.0.0.1:5176,http://localhost:5176"
$env:CSRF_TRUSTED_ORIGINS = "http://127.0.0.1:4173,http://localhost:4173,http://127.0.0.1:5176,http://localhost:5176"

function Find-Python {
  $candidates = @()
  $c1 = Get-Command python -ErrorAction SilentlyContinue
  if ($c1) { $candidates += $c1.Source }
  $c2 = Get-Command py -ErrorAction SilentlyContinue
  if ($c2) { $candidates += $c2.Source }
  $candidates += @(
    "$env:LocalAppData\Programs\Python\Python312\python.exe",
    "$env:LocalAppData\Programs\Python\Python311\python.exe",
    "C:\Python312\python.exe"
  )
  foreach ($c in $candidates) {
    if ($c -and (Test-Path -LiteralPath $c)) { return $c }
  }
  return $null
}

function Write-LocalEnv($path) {
  @(
    "DJANGO_SECRET_KEY=unisearch-local-desktop-key-2026",
    "DJANGO_DEBUG=1",
    "DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1",
    "DJANGO_ADMIN_PATH=admin",
    "DJANGO_USE_SQLITE=1",
    "CORS_ALLOWED_ORIGINS=http://127.0.0.1:4173,http://localhost:4173,http://127.0.0.1:5176,http://localhost:5176",
    "CSRF_TRUSTED_ORIGINS=http://127.0.0.1:4173,http://localhost:4173,http://127.0.0.1:5176,http://localhost:5176"
  ) | Set-Content -Path $path -Encoding ascii
}

function Stop-PortListeners([int[]]$ports) {
  # netstat is much faster than Get-NetTCPConnection on Windows
  $lines = netstat -ano 2>$null
  foreach ($line in $lines) {
    foreach ($port in $ports) {
      if ($line -match "LISTENING\s+(\d+)\s*$" -and $line -match ":$port\s") {
        $procId = [int]$Matches[1]
        if ($procId -gt 0) {
          Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
        }
      }
    }
  }
}

try {
  Write-Host "=== UniSearch ===" -ForegroundColor Cyan

  $py = Find-Python
  if (-not $py) {
    Write-Host "Python not found. Install Python 3.12 and enable Add to PATH." -ForegroundColor Red
    Write-Host "https://www.python.org/downloads/"
    exit 1
  }

  $be = Join-Path $PSScriptRoot "backend"
  $site = Join-Path $PSScriptRoot "site"
  if (-not (Test-Path (Join-Path $site "index.html"))) {
    Write-Host "site/index.html missing." -ForegroundColor Red
    exit 1
  }

  $venvPy = Join-Path $be ".venv\Scripts\python.exe"
  $venvPip = Join-Path $be ".venv\Scripts\pip.exe"
  $reqs = Join-Path $be "requirements.txt"
  $ready = Join-Path $be ".unisearch_ready"
  $db = Join-Path $be "db.sqlite3"
  $envFile = Join-Path $be ".env"

  $needSetup = $false
  if (-not (Test-Path $venvPy)) { $needSetup = $true }
  elseif (-not (Test-Path $ready)) { $needSetup = $true }
  elseif (-not (Test-Path $db)) { $needSetup = $true }
  elseif ((Test-Path $reqs) -and (Test-Path $ready)) {
    if ((Get-Item $reqs).LastWriteTimeUtc -gt (Get-Item $ready).LastWriteTimeUtc) { $needSetup = $true }
  }

  if ($needSetup) {
    if (-not (Test-Path $venvPy)) {
      Write-Host "[1/3] Creating Python environment (first run only)..."
      & $py -m venv (Join-Path $be ".venv")
      if (-not (Test-Path $venvPy)) { throw "venv python missing after create" }
    } else {
      Write-Host "[1/3] venv OK"
    }

    Write-Host "[2/3] Installing packages (first run only, may take 1-3 min)..."
    & $venvPip install -r $reqs --disable-pip-version-check --quiet
    if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

    Write-LocalEnv $envFile

    Write-Host "[3/3] Database setup (first run only)..."
    Push-Location $be
    & $venvPy manage.py migrate --noinput
    if ($LASTEXITCODE -ne 0) { throw "migrate failed" }
    & $venvPy manage.py seed_catalog
    if ($LASTEXITCODE -ne 0) { throw "seed_catalog failed" }

    $adminEmail = "cabinet@unisearch.local"
    $adminPass = "UniSearch-Cabinet-4821"
    $passFile = Join-Path $PSScriptRoot "ADMIN.txt"
    @(
      "EMAIL=$adminEmail",
      "PASSWORD=$adminPass",
      "",
      "1. Open http://127.0.0.1:4173/admin/login",
      "2. Email: $adminEmail",
      "3. Password: $adminPass",
      "4. Then open http://127.0.0.1:4173/admin"
    ) | Set-Content -Path $passFile -Encoding ascii

    $env:UNISEARCH_ADMIN_EMAIL = $adminEmail
    $env:UNISEARCH_ADMIN_PASSWORD = $adminPass
    $ensureAdmin = @'
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from django.contrib.auth import get_user_model
from django.db.models import Q
U = get_user_model()
email = os.environ["UNISEARCH_ADMIN_EMAIL"].strip().lower()
pwd = os.environ["UNISEARCH_ADMIN_PASSWORD"]
u = U.objects.filter(Q(email__iexact=email) | Q(email__iexact="admin@unisearch.local") | Q(username="cabinet") | Q(username="admin")).order_by("id").first()
if not u:
    U.objects.create_superuser(username="cabinet", email=email, password=pwd, name="Admin")
else:
    u.username = "cabinet"
    u.email = email
    u.name = u.name or "Admin"
    u.is_staff = True
    u.is_superuser = True
    u.is_active = True
    u.set_password(pwd)
    u.save()
assert U.objects.get(username="cabinet").check_password(pwd)
print("admin OK")
'@
    $adminPy = Join-Path $be "_ensure_admin.py"
    [System.IO.File]::WriteAllText($adminPy, $ensureAdmin)
    & $venvPy $adminPy
    if ($LASTEXITCODE -ne 0) { throw "Admin setup failed" }
    Remove-Item $adminPy -Force -ErrorAction SilentlyContinue
    Pop-Location

    Set-Content -Path $ready -Value (Get-Date -Format o) -Encoding ascii
    Write-Host "First-run setup complete." -ForegroundColor Green
  } else {
    Write-Host "Quick start (setup already done)..." -ForegroundColor Green
    if (-not (Test-Path $envFile)) { Write-LocalEnv $envFile }
    Push-Location $be
    & $venvPy manage.py migrate --noinput
    if ($LASTEXITCODE -ne 0) { throw "migrate failed" }
    Pop-Location
  }

  Write-Host "Starting servers..."
  Stop-PortListeners @(8000, 4173)

  $api = Start-Process -FilePath $venvPy `
    -ArgumentList @("manage.py", "runserver", "127.0.0.1:8000", "--noreload") `
    -WorkingDirectory $be `
    -PassThru `
    -WindowStyle Minimized

  $sitePy = @'
import http.server, socketserver, os, sys
PORT = 4173
ROOT = sys.argv[1]
os.chdir(ROOT)

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**getattr(http.server.SimpleHTTPRequestHandler, "extensions_map", {}),
      ".js": "text/javascript", ".mjs": "text/javascript",
      ".css": "text/css", ".json": "application/json",
      ".wasm": "application/wasm", ".svg": "image/svg+xml"}
    def log_message(self, fmt, *args):
        pass
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        fs = self.translate_path(path)
        if path != "/" and not os.path.isfile(fs):
            self.path = "/index.html"
        return super().do_GET()

socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", PORT), Handler) as httpd:
    httpd.serve_forever()
'@
  $siteScript = Join-Path $be "_serve_site.py"
  [System.IO.File]::WriteAllText($siteScript, $sitePy)
  $web = Start-Process -FilePath $venvPy `
    -ArgumentList @($siteScript, $site) `
    -WorkingDirectory $be `
    -PassThru `
    -WindowStyle Minimized

  # Wait briefly for API readiness (max ~4s)
  $up = $false
  for ($i = 0; $i -lt 8; $i++) {
    Start-Sleep -Milliseconds 500
    if ($api.HasExited) { throw "API server exited immediately" }
    if ($web.HasExited) { throw "Website server failed on port 4173" }
    try {
      $r = Invoke-WebRequest -Uri "http://127.0.0.1:8000/api/v1/health/" -UseBasicParsing -TimeoutSec 1
      if ($r.StatusCode -ge 200) { $up = $true; break }
    } catch {}
  }
  if (-not $up -and $api.HasExited) { throw "API failed to start" }

  Start-Process "http://127.0.0.1:4173/"
  Write-Host ""
  Write-Host "Site:  http://127.0.0.1:4173/" -ForegroundColor Green
  Write-Host "UniTrack: http://127.0.0.1:4173/unitrack" -ForegroundColor Green
  Write-Host "Admin: http://127.0.0.1:4173/admin" -ForegroundColor Green
  Write-Host "Login: cabinet@unisearch.local / UniSearch-Cabinet-4821" -ForegroundColor Green
  Write-Host "Close this window to stop." -ForegroundColor Yellow

  try {
    while ($true) {
      if ($api.HasExited) { throw "API server stopped unexpectedly" }
      if ($web.HasExited) { throw "Website server stopped unexpectedly" }
      Start-Sleep -Seconds 3
    }
  } finally {
    try { if ($web -and -not $web.HasExited) { Stop-Process -Id $web.Id -Force } } catch {}
    try { if ($api -and -not $api.HasExited) { Stop-Process -Id $api.Id -Force } } catch {}
    Remove-Item $siteScript -Force -ErrorAction SilentlyContinue
  }
}
catch {
  Write-Host ""
  Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host $_.ScriptStackTrace -ForegroundColor DarkRed
  exit 1
}
